/**
 * whatsapp — port of convex/whatsapp/{contacts,audiences,conversations,messages,
 * campaigns,fallback}.ts to Cloudflare Workers + Hono over D1.
 *
 * Owner-scoped (RLS: auth.uid() = user_id) except templates_fallback, which is
 * email-scoped (the Postgres "Templates" table matched on auth.jwt()->>'email').
 * Two parallel audience systems coexist (schema warning 5):
 *   System A: whatsapp_audiences + whatsapp_audience_contacts -> whatsapp_contacts
 *   System B: audience_segments + audience_segment_contacts   -> VOICE `contacts`
 *
 * JSON columns (D1 stores as TEXT; db.ts helpers parse/serialize):
 *   whatsapp_contacts.metadata, whatsapp_messages.raw_payload,
 *   whatsapp_campaigns.{outcomes,template_structure}, templates_fallback.carousel_data.
 * Enums: whatsapp_messages.{direction,status}, whatsapp_campaigns.status.
 *
 * Outbound sends go through the Meta WhatsApp Graph API for real: one-off
 * replies and direct sends inline, and campaigns through runWhatsappBatch — a
 * bounded, resumable batch driven on ctx.waitUntil (see ../campaign-runner).
 */
import { Hono } from "hono";
import { requireUser } from "../auth";
import { mapRow, mapRows, buildInsert, buildUpdate, newId } from "../db";
import * as WA from "../whatsapp-helpers";
import { sleep } from "../messaging-send";
import {
  BATCH_MAX_CONTACTS,
  createBudget,
  loadDncSet,
  loadSafetySettings,
  readStatus,
  type ResumePlan,
} from "../campaign-runner";

type Env = { Bindings: { DB: D1Database }; Variables: { userId: string } };

const DEFAULT_TAG = "WhatsApp Segment";

/** Convex's WHATSAPP_SEND_DELAY_MS — the edge function's hardcoded sleep(100). */
const WHATSAPP_SEND_DELAY_MS = 100;

const CONTACT_SPEC = { json: ["metadata"], bool: [] as string[] };
const AUDIENCE_SPEC = { json: [] as string[], bool: [] as string[] };
const CONVERSATION_SPEC = { json: [] as string[], bool: [] as string[] };
const MESSAGE_SPEC = { json: ["raw_payload"], bool: [] as string[] };
const CAMPAIGN_SPEC = { json: ["outcomes", "template_structure"], bool: [] as string[] };
const FALLBACK_SPEC = { json: ["carousel_data"], bool: [] as string[] };
const SEGMENT_SPEC = { json: [] as string[], bool: [] as string[] };

/** created_at ?? _creation_time, for the newest-first sorts Convex used. */
const createdAtOf = (r: Record<string, any>): number => r.created_at ?? r._creation_time ?? 0;

const app = new Hono<Env>();
app.use("*", requireUser);

// ===========================================================================
// whatsapp_contacts  (convex/whatsapp/contacts.ts)
// ===========================================================================

/** Upsert one contact on (user_id, phone_number). Returns the row id. */
async function upsertContact(
  c: any,
  userId: string,
  contact: { name: string; phone_number: string; email?: string | null; metadata?: unknown },
): Promise<string> {
  const now = Date.now();
  const existing = await c.env.DB.prepare(
    "SELECT * FROM whatsapp_contacts WHERE user_id = ? AND phone_number = ?",
  )
    .bind(userId, contact.phone_number)
    .first();
  if (existing) {
    const ex = existing as Record<string, any>;
    const patch: Record<string, unknown> = {
      name: contact.name,
      email: contact.email ?? null,
      metadata: contact.metadata ?? mapRow(ex, CONTACT_SPEC)!.metadata ?? {},
      updated_at: now,
    };
    const { sql, binds } = buildUpdate("whatsapp_contacts", patch);
    await c.env.DB.prepare(sql).bind(...binds, ex.id).run();
    return ex.id;
  }
  const id = newId();
  const doc = {
    id,
    _creation_time: now,
    user_id: userId,
    name: contact.name,
    phone_number: contact.phone_number,
    email: contact.email ?? null,
    metadata: contact.metadata ?? {},
    created_at: now,
    updated_at: now,
  };
  const { sql, binds } = buildInsert("whatsapp_contacts", doc);
  await c.env.DB.prepare(sql).bind(...binds).run();
  return id;
}

/** GET /whatsapp/contacts — the user's contacts, newest first. */
app.get("/contacts", async (c) => {
  const userId = c.get("userId");
  const { results } = await c.env.DB.prepare("SELECT * FROM whatsapp_contacts WHERE user_id = ?")
    .bind(userId)
    .all();
  const rows = mapRows<Record<string, any>>(results as Record<string, unknown>[], CONTACT_SPEC);
  rows.sort((a, b) => createdAtOf(b) - createdAtOf(a));
  return c.json(rows);
});

/** POST /whatsapp/contacts — upsert one contact on (user_id, phone_number). */
app.post("/contacts", async (c) => {
  const userId = c.get("userId");
  const b = await c.req.json<Record<string, any>>();
  const id = await upsertContact(c, userId, {
    name: b.name,
    phone_number: b.phone_number,
    email: b.email,
    metadata: b.metadata,
  });
  const created = await c.env.DB.prepare("SELECT * FROM whatsapp_contacts WHERE id = ?").bind(id).first();
  return c.json(mapRow(created as Record<string, unknown>, CONTACT_SPEC), 201);
});

/** POST /whatsapp/contacts/bulk — CSV import; dedupes by phone (last wins). */
app.post("/contacts/bulk", async (c) => {
  const userId = c.get("userId");
  const b = await c.req.json<{ contacts: Array<Record<string, any>> }>();
  const deduped = Array.from(
    new Map((b.contacts ?? []).map((ct) => [String(ct.phone_number).trim().toLowerCase(), ct])).values(),
  );
  const ids: string[] = [];
  for (const contact of deduped) {
    ids.push(
      await upsertContact(c, userId, {
        name: contact.name,
        phone_number: contact.phone_number,
        email: contact.email,
        metadata: contact.metadata,
      }),
    );
  }
  return c.json({ ids }, 201);
});

/** PATCH /whatsapp/contacts/:id — owner-scoped edit; enforces phone uniqueness. */
app.patch("/contacts/:id", async (c) => {
  const userId = c.get("userId");
  const id = c.req.param("id");
  const existing = await c.env.DB.prepare("SELECT * FROM whatsapp_contacts WHERE id = ?").bind(id).first();
  if (!existing || (existing as any).user_id !== userId) return c.json({ error: "Contact not found" }, 404);
  const ex = existing as Record<string, any>;
  const b = await c.req.json<Record<string, any>>();

  if (b.phone_number !== undefined && b.phone_number !== ex.phone_number) {
    const conflict = await c.env.DB.prepare(
      "SELECT id FROM whatsapp_contacts WHERE user_id = ? AND phone_number = ?",
    )
      .bind(userId, b.phone_number)
      .first();
    if (conflict && (conflict as any).id !== id) {
      return c.json({ error: "A contact with this phone number already exists" }, 409);
    }
  }

  const patch: Record<string, unknown> = { updated_at: Date.now() };
  if (b.name !== undefined) patch.name = b.name;
  if (b.phone_number !== undefined) patch.phone_number = b.phone_number;
  if (b.email !== undefined) patch.email = b.email; // null clears
  if (b.metadata !== undefined) patch.metadata = b.metadata;
  const { sql, binds } = buildUpdate("whatsapp_contacts", patch);
  await c.env.DB.prepare(sql).bind(...binds, id).run();
  const updated = await c.env.DB.prepare("SELECT * FROM whatsapp_contacts WHERE id = ?").bind(id).first();
  return c.json(mapRow(updated as Record<string, unknown>, CONTACT_SPEC));
});

/** DELETE /whatsapp/contacts/:id — cascade whatsapp_audience_contacts links. */
app.delete("/contacts/:id", async (c) => {
  const userId = c.get("userId");
  const id = c.req.param("id");
  const existing = await c.env.DB.prepare("SELECT user_id FROM whatsapp_contacts WHERE id = ?").bind(id).first();
  if (!existing || (existing as any).user_id !== userId) return c.json({ error: "Contact not found" }, 404);
  await c.env.DB.batch([
    c.env.DB.prepare("DELETE FROM whatsapp_audience_contacts WHERE contact_id = ?").bind(id),
    c.env.DB.prepare("DELETE FROM whatsapp_contacts WHERE id = ?").bind(id),
  ]);
  return c.json({ success: true });
});

// ===========================================================================
// System A — whatsapp_audiences (+ whatsapp_audience_contacts)
// ===========================================================================

/** Link whatsapp_contacts to an audience, skipping cross-owner + duplicates. */
async function linkWhatsappContacts(
  c: any,
  userId: string,
  audienceId: string,
  contactIds: string[],
): Promise<void> {
  const now = Date.now();
  for (const contactId of contactIds) {
    const contact = await c.env.DB.prepare("SELECT user_id FROM whatsapp_contacts WHERE id = ?")
      .bind(contactId)
      .first();
    if (!contact || (contact as any).user_id !== userId) throw new Error("Contact not found");
    const existing = await c.env.DB.prepare(
      "SELECT id FROM whatsapp_audience_contacts WHERE audience_id = ? AND contact_id = ?",
    )
      .bind(audienceId, contactId)
      .first();
    if (existing) continue;
    const { sql, binds } = buildInsert("whatsapp_audience_contacts", {
      id: newId(),
      _creation_time: now,
      user_id: userId,
      audience_id: audienceId,
      contact_id: contactId,
      created_at: now,
    });
    await c.env.DB.prepare(sql).bind(...binds).run();
  }
}

/** GET /whatsapp/audiences — audiences with membership, newest first. */
app.get("/audiences", async (c) => {
  const userId = c.get("userId");
  const [aRes, lRes] = await c.env.DB.batch([
    c.env.DB.prepare("SELECT * FROM whatsapp_audiences WHERE user_id = ?").bind(userId),
    c.env.DB.prepare("SELECT * FROM whatsapp_audience_contacts WHERE user_id = ?").bind(userId),
  ]);
  const audiences = mapRows<Record<string, any>>(
    (aRes as any).results as Record<string, unknown>[],
    AUDIENCE_SPEC,
  );
  const links = (lRes as any).results as Array<Record<string, any>>;
  const byAudience = new Map<string, string[]>();
  for (const link of links) {
    const key = String(link.audience_id);
    const cur = byAudience.get(key) ?? [];
    cur.push(link.contact_id);
    byAudience.set(key, cur);
  }
  const out = audiences
    .sort((a, b) => createdAtOf(b) - createdAtOf(a))
    .map((audience) => {
      const contactIds = byAudience.get(String(audience.id)) ?? [];
      return { ...audience, tag: audience.tag ?? DEFAULT_TAG, members: contactIds.length, contactIds };
    });
  return c.json(out);
});

/** GET /whatsapp/audiences/:id/contacts — contact ids of one owned audience. */
app.get("/audiences/:id/contacts", async (c) => {
  const userId = c.get("userId");
  const id = c.req.param("id");
  const audience = await c.env.DB.prepare("SELECT user_id FROM whatsapp_audiences WHERE id = ?").bind(id).first();
  if (!audience || (audience as any).user_id !== userId) return c.json([]);
  const { results } = await c.env.DB.prepare(
    "SELECT contact_id FROM whatsapp_audience_contacts WHERE audience_id = ?",
  )
    .bind(id)
    .all();
  return c.json((results as Array<Record<string, any>>).map((r) => r.contact_id));
});

/** POST /whatsapp/audiences — create (+ optional initial member links). */
app.post("/audiences", async (c) => {
  const userId = c.get("userId");
  const b = await c.req.json<Record<string, any>>();
  const name = String(b.name ?? "").trim();
  if (!name) return c.json({ error: "name is required" }, 400);
  const now = Date.now();
  const id = newId();
  const { sql, binds } = buildInsert("whatsapp_audiences", {
    id,
    _creation_time: now,
    user_id: userId,
    name,
    description: b.description ?? null,
    tag: b.tag ?? DEFAULT_TAG,
    created_at: now,
    updated_at: now,
  });
  await c.env.DB.prepare(sql).bind(...binds).run();
  try {
    await linkWhatsappContacts(c, userId, id, b.contactIds ?? []);
  } catch (e) {
    return c.json({ error: (e as Error).message }, 400);
  }
  return c.json({ id }, 201);
});

/** PATCH /whatsapp/audiences/:id — patch; contactIds replaces membership. */
app.patch("/audiences/:id", async (c) => {
  const userId = c.get("userId");
  const id = c.req.param("id");
  const audience = await c.env.DB.prepare("SELECT user_id FROM whatsapp_audiences WHERE id = ?").bind(id).first();
  if (!audience || (audience as any).user_id !== userId) return c.json({ error: "Audience not found" }, 404);
  const b = await c.req.json<Record<string, any>>();

  const patch: Record<string, unknown> = { updated_at: Date.now() };
  if (b.name !== undefined) patch.name = String(b.name).trim();
  if (b.description !== undefined) patch.description = b.description; // null clears
  if (b.tag !== undefined) patch.tag = b.tag;
  const { sql, binds } = buildUpdate("whatsapp_audiences", patch);
  await c.env.DB.prepare(sql).bind(...binds, id).run();

  if (b.contactIds !== undefined) {
    await c.env.DB.prepare("DELETE FROM whatsapp_audience_contacts WHERE audience_id = ?").bind(id).run();
    try {
      await linkWhatsappContacts(c, userId, id, b.contactIds);
    } catch (e) {
      return c.json({ error: (e as Error).message }, 400);
    }
  }
  return c.json({ id });
});

/** DELETE /whatsapp/audiences/:id — cascade links, detach campaigns (SET NULL). */
app.delete("/audiences/:id", async (c) => {
  const userId = c.get("userId");
  const id = c.req.param("id");
  const audience = await c.env.DB.prepare("SELECT user_id FROM whatsapp_audiences WHERE id = ?").bind(id).first();
  if (!audience || (audience as any).user_id !== userId) return c.json({ error: "Audience not found" }, 404);
  await c.env.DB.batch([
    c.env.DB.prepare("DELETE FROM whatsapp_audience_contacts WHERE audience_id = ?").bind(id),
    c.env.DB.prepare("UPDATE whatsapp_campaigns SET audience_id = NULL WHERE audience_id = ?").bind(id),
    c.env.DB.prepare("DELETE FROM whatsapp_audiences WHERE id = ?").bind(id),
  ]);
  return c.json({ success: true });
});

// ===========================================================================
// System B — audience_segments (+ audience_segment_contacts -> voice contacts)
// ===========================================================================

/** Link VOICE `contacts` to a segment (intentional cross-table FK). */
async function linkVoiceContacts(
  c: any,
  userId: string,
  audienceId: string,
  contactIds: string[],
): Promise<void> {
  const now = Date.now();
  for (const contactId of contactIds) {
    const contact = await c.env.DB.prepare("SELECT user_id FROM contacts WHERE id = ?").bind(contactId).first();
    if (!contact || (contact as any).user_id !== userId) throw new Error("Contact not found");
    const existing = await c.env.DB.prepare(
      "SELECT id FROM audience_segment_contacts WHERE audience_id = ? AND contact_id = ?",
    )
      .bind(audienceId, contactId)
      .first();
    if (existing) continue;
    const { sql, binds } = buildInsert("audience_segment_contacts", {
      id: newId(),
      _creation_time: now,
      user_id: userId,
      audience_id: audienceId,
      contact_id: contactId,
      created_at: now,
    });
    await c.env.DB.prepare(sql).bind(...binds).run();
  }
}

/** GET /whatsapp/segments — fallback segments + the user's voice contacts. */
app.get("/segments", async (c) => {
  const userId = c.get("userId");
  const [sRes, lRes, vRes] = await c.env.DB.batch([
    c.env.DB.prepare("SELECT * FROM audience_segments WHERE user_id = ?").bind(userId),
    c.env.DB.prepare("SELECT * FROM audience_segment_contacts WHERE user_id = ?").bind(userId),
    c.env.DB.prepare("SELECT * FROM contacts WHERE user_id = ?").bind(userId),
  ]);
  const segments = mapRows<Record<string, any>>((sRes as any).results as Record<string, unknown>[], SEGMENT_SPEC);
  const links = (lRes as any).results as Array<Record<string, any>>;
  const voiceContacts = (vRes as any).results as Array<Record<string, any>>;

  const contacts = voiceContacts
    .sort((a, b) => createdAtOf(b) - createdAtOf(a))
    .map((ct) => ({ id: ct.id, name: String(ct.first_name ?? "").trim() || ct.phone_number, phone: ct.phone_number }));

  const byAudience = new Map<string, string[]>();
  for (const link of links) {
    const key = String(link.audience_id);
    const cur = byAudience.get(key) ?? [];
    cur.push(link.contact_id);
    byAudience.set(key, cur);
  }

  const audiences = segments
    .sort((a, b) => createdAtOf(b) - createdAtOf(a))
    .map((segment) => {
      const contactIds = byAudience.get(String(segment.id)) ?? [];
      return {
        ...segment,
        description: segment.description ?? "",
        tag: segment.tag ?? DEFAULT_TAG,
        members: contactIds.length,
        contactIds,
      };
    });

  return c.json({ audiences, contacts });
});

/** POST /whatsapp/segments — create a segment (+ optional voice-contact links). */
app.post("/segments", async (c) => {
  const userId = c.get("userId");
  const b = await c.req.json<Record<string, any>>();
  const name = String(b.name ?? "").trim();
  if (!name) return c.json({ error: "name is required" }, 400);
  const now = Date.now();
  const id = newId();
  const { sql, binds } = buildInsert("audience_segments", {
    id,
    _creation_time: now,
    user_id: userId,
    name,
    description: b.description ?? null,
    tag: DEFAULT_TAG,
    created_at: now,
    updated_at: now,
  });
  await c.env.DB.prepare(sql).bind(...binds).run();
  try {
    await linkVoiceContacts(c, userId, id, b.contactIds ?? []);
  } catch (e) {
    return c.json({ error: (e as Error).message }, 400);
  }
  return c.json({ id }, 201);
});

/** PATCH /whatsapp/segments/:id — patch; contactIds replaces membership. */
app.patch("/segments/:id", async (c) => {
  const userId = c.get("userId");
  const id = c.req.param("id");
  const segment = await c.env.DB.prepare("SELECT user_id FROM audience_segments WHERE id = ?").bind(id).first();
  if (!segment || (segment as any).user_id !== userId) return c.json({ error: "Audience not found" }, 404);
  const b = await c.req.json<Record<string, any>>();

  const patch: Record<string, unknown> = { tag: DEFAULT_TAG, updated_at: Date.now() };
  if (b.name !== undefined) patch.name = String(b.name).trim();
  if (b.description !== undefined) patch.description = b.description; // null clears
  const { sql, binds } = buildUpdate("audience_segments", patch);
  await c.env.DB.prepare(sql).bind(...binds, id).run();

  if (b.contactIds !== undefined) {
    await c.env.DB.prepare("DELETE FROM audience_segment_contacts WHERE audience_id = ?").bind(id).run();
    try {
      await linkVoiceContacts(c, userId, id, b.contactIds);
    } catch (e) {
      return c.json({ error: (e as Error).message }, 400);
    }
  }
  return c.json({ id });
});

/** DELETE /whatsapp/segments/:id — cascade links, detach audience_campaigns. */
app.delete("/segments/:id", async (c) => {
  const userId = c.get("userId");
  const id = c.req.param("id");
  const segment = await c.env.DB.prepare("SELECT user_id FROM audience_segments WHERE id = ?").bind(id).first();
  if (!segment || (segment as any).user_id !== userId) return c.json({ error: "Audience not found" }, 404);
  await c.env.DB.batch([
    c.env.DB.prepare("DELETE FROM audience_segment_contacts WHERE audience_id = ?").bind(id),
    c.env.DB.prepare("UPDATE audience_campaigns SET audience_id = NULL WHERE audience_id = ?").bind(id),
    c.env.DB.prepare("DELETE FROM audience_segments WHERE id = ?").bind(id),
  ]);
  return c.json({ success: true });
});

// ===========================================================================
// whatsapp_conversations  (convex/whatsapp/conversations.ts)
// ===========================================================================

/** Upsert a conversation on (user_id, phone_number). Returns the thread id. */
async function upsertConversationRow(
  c: any,
  userId: string,
  args: { phone_number: string; contact_name?: string; last_message_text?: string; last_message_at?: number },
): Promise<string> {
  const now = Date.now();
  const existing = await c.env.DB.prepare(
    "SELECT * FROM whatsapp_conversations WHERE user_id = ? AND phone_number = ?",
  )
    .bind(userId, args.phone_number)
    .first();
  if (existing) {
    const ex = existing as Record<string, any>;
    const patch: Record<string, unknown> = { updated_at: now };
    const name = String(args.contact_name ?? "").trim();
    if (name) patch.contact_name = name;
    if (args.last_message_text !== undefined) patch.last_message_text = args.last_message_text;
    if (args.last_message_at !== undefined) patch.last_message_at = args.last_message_at;
    const { sql, binds } = buildUpdate("whatsapp_conversations", patch);
    await c.env.DB.prepare(sql).bind(...binds, ex.id).run();
    return ex.id;
  }
  const id = newId();
  const { sql, binds } = buildInsert("whatsapp_conversations", {
    id,
    _creation_time: now,
    user_id: userId,
    phone_number: args.phone_number,
    contact_name: String(args.contact_name ?? "").trim() || args.phone_number,
    last_message_text: args.last_message_text ?? null,
    last_message_at: args.last_message_at ?? null,
    unread_count: 0,
    created_at: now,
    updated_at: now,
  });
  await c.env.DB.prepare(sql).bind(...binds).run();
  return id;
}

/** Sort threads by last_message_at DESC, NULLS LAST, then created_at DESC. */
function sortByLastMessageDesc(rows: Array<Record<string, any>>): Array<Record<string, any>> {
  return [...rows].sort((a, b) => {
    const aHas = a.last_message_at != null;
    const bHas = b.last_message_at != null;
    if (aHas && bHas) return (b.last_message_at ?? 0) - (a.last_message_at ?? 0);
    if (aHas) return -1;
    if (bHas) return 1;
    return createdAtOf(b) - createdAtOf(a);
  });
}

/** GET /whatsapp/conversations — all threads, newest-message first. */
app.get("/conversations", async (c) => {
  const userId = c.get("userId");
  const { results } = await c.env.DB.prepare("SELECT * FROM whatsapp_conversations WHERE user_id = ?")
    .bind(userId)
    .all();
  const rows = mapRows<Record<string, any>>(results as Record<string, unknown>[], CONVERSATION_SPEC);
  return c.json(sortByLastMessageDesc(rows));
});

/** GET /whatsapp/conversations/by-phone/:phone — owner-scoped or null. */
app.get("/conversations/by-phone/:phone", async (c) => {
  const userId = c.get("userId");
  const row = await c.env.DB.prepare(
    "SELECT * FROM whatsapp_conversations WHERE user_id = ? AND phone_number = ?",
  )
    .bind(userId, c.req.param("phone"))
    .first();
  return c.json(row ? mapRow(row as Record<string, unknown>, CONVERSATION_SPEC) : null);
});

/** GET /whatsapp/conversations/:id — owner-scoped or null. */
app.get("/conversations/:id", async (c) => {
  const userId = c.get("userId");
  const row = await c.env.DB.prepare("SELECT * FROM whatsapp_conversations WHERE id = ?")
    .bind(c.req.param("id"))
    .first();
  if (!row || (row as any).user_id !== userId) return c.json(null);
  return c.json(mapRow(row as Record<string, unknown>, CONVERSATION_SPEC));
});

/** POST /whatsapp/conversations — upsert on (user_id, phone_number). */
app.post("/conversations", async (c) => {
  const userId = c.get("userId");
  const b = await c.req.json<Record<string, any>>();
  const id = await upsertConversationRow(c, userId, {
    phone_number: b.phone_number,
    contact_name: b.contact_name,
    last_message_text: b.last_message_text ?? undefined,
    last_message_at: b.last_message_at ?? undefined,
  });
  const created = await c.env.DB.prepare("SELECT * FROM whatsapp_conversations WHERE id = ?").bind(id).first();
  return c.json(mapRow(created as Record<string, unknown>, CONVERSATION_SPEC), 201);
});

/** PATCH /whatsapp/conversations/:id — rename / mark read / bump. */
app.patch("/conversations/:id", async (c) => {
  const userId = c.get("userId");
  const id = c.req.param("id");
  const existing = await c.env.DB.prepare("SELECT user_id FROM whatsapp_conversations WHERE id = ?").bind(id).first();
  if (!existing || (existing as any).user_id !== userId) return c.json({ error: "Conversation not found" }, 404);
  const b = await c.req.json<Record<string, any>>();
  const patch: Record<string, unknown> = { updated_at: Date.now() };
  if (b.contact_name !== undefined) patch.contact_name = b.contact_name;
  if (b.last_message_text !== undefined) patch.last_message_text = b.last_message_text; // null clears
  if (b.last_message_at !== undefined) patch.last_message_at = b.last_message_at; // null clears
  if (b.unread_count !== undefined) patch.unread_count = b.unread_count;
  const { sql, binds } = buildUpdate("whatsapp_conversations", patch);
  await c.env.DB.prepare(sql).bind(...binds, id).run();
  const updated = await c.env.DB.prepare("SELECT * FROM whatsapp_conversations WHERE id = ?").bind(id).first();
  return c.json(mapRow(updated as Record<string, unknown>, CONVERSATION_SPEC));
});

/** POST /whatsapp/conversations/:id/mark-read — reset unread_count to 0. */
app.post("/conversations/:id/mark-read", async (c) => {
  const userId = c.get("userId");
  const id = c.req.param("id");
  const existing = await c.env.DB.prepare("SELECT user_id FROM whatsapp_conversations WHERE id = ?").bind(id).first();
  if (!existing || (existing as any).user_id !== userId) return c.json({ error: "Conversation not found" }, 404);
  const { sql, binds } = buildUpdate("whatsapp_conversations", { unread_count: 0, updated_at: Date.now() });
  await c.env.DB.prepare(sql).bind(...binds, id).run();
  return c.json({ success: true });
});

/** DELETE /whatsapp/conversations/:id — cascade its messages. */
app.delete("/conversations/:id", async (c) => {
  const userId = c.get("userId");
  const id = c.req.param("id");
  const existing = await c.env.DB.prepare("SELECT user_id FROM whatsapp_conversations WHERE id = ?").bind(id).first();
  if (!existing || (existing as any).user_id !== userId) return c.json({ error: "Conversation not found" }, 404);
  await c.env.DB.batch([
    c.env.DB.prepare("DELETE FROM whatsapp_messages WHERE conversation_id = ?").bind(id),
    c.env.DB.prepare("DELETE FROM whatsapp_conversations WHERE id = ?").bind(id),
  ]);
  return c.json({ success: true });
});

// ===========================================================================
// whatsapp_messages  (convex/whatsapp/messages.ts) — select/insert/update, no delete
// ===========================================================================

/** GET /whatsapp/conversations/:id/messages — thread messages, oldest first. */
app.get("/conversations/:id/messages", async (c) => {
  const userId = c.get("userId");
  const id = c.req.param("id");
  const conversation = await c.env.DB.prepare("SELECT user_id FROM whatsapp_conversations WHERE id = ?").bind(id).first();
  if (!conversation || (conversation as any).user_id !== userId) return c.json([]);
  const { results } = await c.env.DB.prepare(
    "SELECT * FROM whatsapp_messages WHERE conversation_id = ? ORDER BY sent_at ASC",
  )
    .bind(id)
    .all();
  return c.json(mapRows<Record<string, any>>(results as Record<string, unknown>[], MESSAGE_SPEC));
});

/**
 * POST /whatsapp/messages — insert one message into a thread and advance the
 * conversation's last_message_*.
 *
 * TODO Phase 3 external (Meta API): the actual outbound send via
 * helpers.sendMetaTextMessage / sendMetaTemplateMessage happens in the Phase-3
 * runner; this route performs only the DB writes (message row + conversation bump).
 */
app.post("/messages", async (c) => {
  const userId = c.get("userId");
  const b = await c.req.json<Record<string, any>>();
  if (b.direction !== "inbound" && b.direction !== "outbound") return c.json({ error: "invalid direction" }, 400);
  const status = b.status ?? "sent";
  if (!["sent", "delivered", "read", "failed"].includes(status)) return c.json({ error: "invalid status" }, 400);

  const conversation = await c.env.DB.prepare("SELECT * FROM whatsapp_conversations WHERE id = ?")
    .bind(b.conversation_id)
    .first();
  if (!conversation || (conversation as any).user_id !== userId) return c.json({ error: "Conversation not found" }, 404);
  const conv = conversation as Record<string, any>;

  const now = Date.now();
  const sentAt = b.sent_at ?? now;
  const messageId = newId();
  const { sql, binds } = buildInsert("whatsapp_messages", {
    id: messageId,
    _creation_time: now,
    conversation_id: b.conversation_id,
    user_id: userId,
    direction: b.direction,
    body: b.body,
    provider_message_id: b.provider_message_id ?? null,
    status,
    error_message: b.error_message ?? null,
    raw_payload: b.raw_payload ?? {},
    sent_at: sentAt,
    created_at: now,
  });
  const bumpUnread =
    b.direction === "inbound" ? (conv.unread_count ?? 0) + 1 : conv.unread_count;
  const { sql: usql, binds: ubinds } = buildUpdate("whatsapp_conversations", {
    last_message_text: b.body,
    last_message_at: sentAt,
    unread_count: bumpUnread,
    updated_at: now,
  });
  await c.env.DB.batch([
    c.env.DB.prepare(sql).bind(...binds),
    c.env.DB.prepare(usql).bind(...ubinds, conv.id),
  ]);
  const created = await c.env.DB.prepare("SELECT * FROM whatsapp_messages WHERE id = ?").bind(messageId).first();
  return c.json(mapRow(created as Record<string, unknown>, MESSAGE_SPEC), 201);
});

// --- outbound send (Meta Graph) ---------------------------------------------
// Port of convex/whatsapp/helpers.ts sendMetaTextMessage. Previously only the
// campaign runner could send, so Chats had no way to deliver a reply.
const GRAPH_VERSION = "v22.0";
const GRAPH_BASE = "https://graph.facebook.com";

/** The caller's Meta credentials, or null when they haven't been connected. */
async function loadMetaCredentials(
  c: any,
  userId: string,
): Promise<{ accessToken: string; phoneNumberId: string } | null> {
  const cfg = (await c.env.DB.prepare(
    "SELECT meta_access_token, meta_phone_number_id FROM whatsapp_api_configs WHERE user_id = ?",
  ).bind(userId).first()) as { meta_access_token: string | null; meta_phone_number_id: string | null } | null;
  const accessToken = (cfg?.meta_access_token ?? "").trim();
  const phoneNumberId = (cfg?.meta_phone_number_id ?? "").trim();
  if (!accessToken || !phoneNumberId) return null;
  return { accessToken, phoneNumberId };
}

/**
 * Send a plain text message to `to` via Meta, then persist it against
 * `conversationId` and bump the thread.
 *
 * The message row is only written after Meta accepts it: a thread that shows a
 * sent bubble the customer never received is worse than a visible failure.
 */
async function sendTextToConversation(
  c: any,
  userId: string,
  conversationId: string,
  to: string,
  text: string,
  creds: { accessToken: string; phoneNumberId: string },
): Promise<{ ok: true; message: Record<string, any> } | { ok: false; error: string }> {
  let payload: any = {};
  try {
    const res = await fetch(`${GRAPH_BASE}/${GRAPH_VERSION}/${creds.phoneNumberId}/messages`, {
      method: "POST",
      headers: { authorization: `Bearer ${creds.accessToken}`, "content-type": "application/json" },
      body: JSON.stringify({
        messaging_product: "whatsapp",
        recipient_type: "individual",
        to,
        type: "text",
        text: { body: text },
      }),
    });
    payload = await res.json().catch(() => ({}));
    if (!res.ok) {
      return {
        ok: false,
        error: payload?.error?.message || payload?.error?.error_user_msg || "WhatsApp send failed",
      };
    }
  } catch (err) {
    return { ok: false, error: err instanceof Error ? err.message : "WhatsApp send failed" };
  }

  const now = Date.now();
  const messageId = newId();
  const { sql, binds } = buildInsert("whatsapp_messages", {
    id: messageId,
    _creation_time: now,
    conversation_id: conversationId,
    user_id: userId,
    direction: "outbound",
    body: text,
    provider_message_id: payload?.messages?.[0]?.id ?? null,
    status: "sent",
    error_message: null,
    raw_payload: payload ?? {},
    sent_at: now,
    created_at: now,
  });
  const { sql: usql, binds: ubinds } = buildUpdate("whatsapp_conversations", {
    last_message_text: text,
    last_message_at: now,
    updated_at: now,
  });
  await c.env.DB.batch([
    c.env.DB.prepare(sql).bind(...binds),
    c.env.DB.prepare(usql).bind(...ubinds, conversationId),
  ]);

  const created = await c.env.DB.prepare("SELECT * FROM whatsapp_messages WHERE id = ?")
    .bind(messageId)
    .first();
  return { ok: true, message: mapRow(created as Record<string, unknown>, MESSAGE_SPEC) as Record<string, any> };
}

/** POST /whatsapp/conversations/:id/send { body } — reply on an existing thread. */
app.post("/conversations/:id/send", async (c) => {
  const userId = c.get("userId");
  const id = c.req.param("id");
  const { body } = await c.req.json<{ body?: string }>();
  const text = (body ?? "").trim();
  if (!text) return c.json({ error: "Message body is required" }, 400);

  const conversation = await c.env.DB.prepare(
    "SELECT * FROM whatsapp_conversations WHERE id = ?",
  ).bind(id).first();
  if (!conversation || (conversation as any).user_id !== userId) {
    return c.json({ error: "Conversation not found" }, 404);
  }
  const conv = conversation as Record<string, any>;

  const creds = await loadMetaCredentials(c, userId);
  if (!creds) {
    return c.json(
      { error: "Connect your Meta WhatsApp credentials first (Tools & Setup → WhatsApp API)." },
      501,
    );
  }

  const to = String(conv.phone_number ?? "").trim();
  if (!to) return c.json({ error: "This conversation has no contact phone number" }, 400);

  const result = await sendTextToConversation(c, userId, id, to, text, creds);
  if (!result.ok) return c.json({ error: result.error }, 502);
  return c.json(result.message, 201);
});

/**
 * POST /whatsapp/send-direct { recipient_number, message, contact_name? } —
 * one-off WhatsApp send from the Unibox composer (send-whatsapp-direct-message
 * port). Resolves-or-creates the thread for that number first, so the message
 * lands in Chats exactly like a reply would.
 *
 * Note this sends a FREE-FORM text, which Meta only delivers inside a 24-hour
 * customer service window. Outside it Meta rejects the send and the caller sees
 * the Graph error verbatim — templates (the campaign path) are the way to open
 * a new conversation.
 */
app.post("/send-direct", async (c) => {
  const userId = c.get("userId");
  const b = await c.req.json<Record<string, any>>().catch(() => ({}) as Record<string, any>);
  const to = WA.normalizePhoneNumber(String(b.recipient_number ?? ""));
  const text = String(b.message ?? "").trim();
  if (!to) return c.json({ error: "recipient_number is required" }, 400);
  if (!text) return c.json({ error: "message is required" }, 400);

  const creds = await loadMetaCredentials(c, userId);
  if (!creds) {
    return c.json(
      { error: "Connect your Meta WhatsApp credentials first (Tools & Setup → WhatsApp API)." },
      501,
    );
  }

  const conversationId = await upsertConversationRow(c, userId, {
    phone_number: to,
    contact_name: String(b.contact_name ?? "").trim() || to,
  });

  const result = await sendTextToConversation(c, userId, conversationId, to, text, creds);
  if (!result.ok) return c.json({ error: result.error }, 502);
  return c.json({ success: true, conversation_id: conversationId, message: result.message }, 201);
});

/** PATCH /whatsapp/messages/:id — delivery-receipt status update (owner-scoped). */
app.patch("/messages/:id", async (c) => {
  const userId = c.get("userId");
  const id = c.req.param("id");
  const message = await c.env.DB.prepare("SELECT user_id FROM whatsapp_messages WHERE id = ?").bind(id).first();
  if (!message || (message as any).user_id !== userId) return c.json({ error: "Message not found" }, 404);
  const b = await c.req.json<Record<string, any>>();
  if (!["sent", "delivered", "read", "failed"].includes(b.status)) return c.json({ error: "invalid status" }, 400);
  const patch: Record<string, unknown> = { status: b.status };
  if (b.error_message !== undefined) patch.error_message = b.error_message; // null clears
  const { sql, binds } = buildUpdate("whatsapp_messages", patch);
  await c.env.DB.prepare(sql).bind(...binds, id).run();
  const updated = await c.env.DB.prepare("SELECT * FROM whatsapp_messages WHERE id = ?").bind(id).first();
  return c.json(mapRow(updated as Record<string, unknown>, MESSAGE_SPEC));
});

// ===========================================================================
// whatsapp_campaigns  (convex/whatsapp/campaigns.ts)
// ===========================================================================

const CAMPAIGN_UPDATABLE = [
  "name",
  "description",
  "audience_id",
  "template_id",
  "status",
  "total_contacts",
  "sent_count",
  "failed_count",
  "outcomes",
  "template_name",
  "template_language",
  "template_structure",
  "delivered",
  "failed",
  "sent_date",
];

/** Validate that referenced audience/template are owned (when non-null). */
async function assertOwnedCampaignRefs(
  c: any,
  userId: string,
  refs: { audience_id?: string | null; template_id?: string | null },
): Promise<string | null> {
  if (refs.audience_id) {
    const audience = await c.env.DB.prepare("SELECT user_id FROM whatsapp_audiences WHERE id = ?")
      .bind(refs.audience_id)
      .first();
    if (!audience || (audience as any).user_id !== userId) return "Audience not found";
  }
  if (refs.template_id) {
    const template = await c.env.DB.prepare("SELECT user_id FROM whatsapp_templates WHERE id = ?")
      .bind(refs.template_id)
      .first();
    if (!template || (template as any).user_id !== userId) return "Template not found";
  }
  return null;
}

/** GET /whatsapp/campaigns — all campaigns, newest first. */
app.get("/campaigns", async (c) => {
  const userId = c.get("userId");
  const { results } = await c.env.DB.prepare("SELECT * FROM whatsapp_campaigns WHERE user_id = ?")
    .bind(userId)
    .all();
  const rows = mapRows<Record<string, any>>(results as Record<string, unknown>[], CAMPAIGN_SPEC);
  rows.sort((a, b) => createdAtOf(b) - createdAtOf(a));
  return c.json(rows);
});

/** GET /whatsapp/campaigns/:id — owner-scoped or null. */
app.get("/campaigns/:id", async (c) => {
  const userId = c.get("userId");
  const row = await c.env.DB.prepare("SELECT * FROM whatsapp_campaigns WHERE id = ?").bind(c.req.param("id")).first();
  if (!row || (row as any).user_id !== userId) return c.json(null);
  return c.json(mapRow(row as Record<string, unknown>, CAMPAIGN_SPEC));
});

/** POST /whatsapp/campaigns — create, applying the Postgres column defaults. */
app.post("/campaigns", async (c) => {
  const userId = c.get("userId");
  const b = await c.req.json<Record<string, any>>();
  const refErr = await assertOwnedCampaignRefs(c, userId, b);
  if (refErr) return c.json({ error: refErr }, 400);
  const now = Date.now();
  const id = newId();
  const doc = {
    id,
    _creation_time: now,
    user_id: userId,
    name: b.name,
    description: b.description ?? null,
    audience_id: b.audience_id ?? null,
    template_id: b.template_id ?? null,
    status: b.status ?? "draft",
    total_contacts: b.total_contacts ?? 0,
    sent_count: b.sent_count ?? 0,
    failed_count: b.failed_count ?? 0,
    outcomes: Array.isArray(b.outcomes) ? b.outcomes : [],
    template_name: b.template_name ?? null,
    template_language: b.template_language ?? null,
    template_structure:
      b.template_structure && typeof b.template_structure === "object" ? b.template_structure : {},
    delivered: b.delivered ?? 0,
    failed: b.failed ?? 0,
    sent_date: b.sent_date ?? null,
    created_at: now,
    updated_at: now,
  };
  const { sql, binds } = buildInsert("whatsapp_campaigns", doc);
  await c.env.DB.prepare(sql).bind(...binds).run();
  const created = await c.env.DB.prepare("SELECT * FROM whatsapp_campaigns WHERE id = ?").bind(id).first();
  return c.json(mapRow(created as Record<string, unknown>, CAMPAIGN_SPEC), 201);
});

/** PATCH /whatsapp/campaigns/:id — patch (owner-scoped); null clears a column. */
app.patch("/campaigns/:id", async (c) => {
  const userId = c.get("userId");
  const id = c.req.param("id");
  const existing = await c.env.DB.prepare("SELECT user_id FROM whatsapp_campaigns WHERE id = ?").bind(id).first();
  if (!existing || (existing as any).user_id !== userId) return c.json({ error: "WhatsApp campaign not found" }, 404);
  const b = await c.req.json<Record<string, any>>();
  const refErr = await assertOwnedCampaignRefs(c, userId, b);
  if (refErr) return c.json({ error: refErr }, 400);
  const patch: Record<string, unknown> = { updated_at: Date.now() };
  for (const key of CAMPAIGN_UPDATABLE) if (key in b) patch[key] = b[key]; // null -> NULL (clears)
  const { sql, binds } = buildUpdate("whatsapp_campaigns", patch);
  await c.env.DB.prepare(sql).bind(...binds, id).run();
  const updated = await c.env.DB.prepare("SELECT * FROM whatsapp_campaigns WHERE id = ?").bind(id).first();
  return c.json(mapRow(updated as Record<string, unknown>, CAMPAIGN_SPEC));
});

/** POST /whatsapp/campaigns/:id/status — pause / resume / halt control. */
app.post("/campaigns/:id/status", async (c) => {
  const userId = c.get("userId");
  const id = c.req.param("id");
  const existing = await c.env.DB.prepare("SELECT user_id FROM whatsapp_campaigns WHERE id = ?").bind(id).first();
  if (!existing || (existing as any).user_id !== userId) return c.json({ error: "WhatsApp campaign not found" }, 404);
  const b = await c.req.json<Record<string, any>>();
  if (!["draft", "active", "completed", "failed"].includes(b.status)) return c.json({ error: "invalid status" }, 400);
  const { sql, binds } = buildUpdate("whatsapp_campaigns", { status: b.status, updated_at: Date.now() });
  await c.env.DB.prepare(sql).bind(...binds, id).run();
  return c.json({ success: true });
});

/** DELETE /whatsapp/campaigns/:id — plain owner-scoped delete. */
app.delete("/campaigns/:id", async (c) => {
  const userId = c.get("userId");
  const id = c.req.param("id");
  const existing = await c.env.DB.prepare("SELECT user_id FROM whatsapp_campaigns WHERE id = ?").bind(id).first();
  if (!existing || (existing as any).user_id !== userId) return c.json({ error: "WhatsApp campaign not found" }, 404);
  await c.env.DB.prepare("DELETE FROM whatsapp_campaigns WHERE id = ?").bind(id).run();
  return c.json({ success: true });
});

/**
 * POST /whatsapp/campaigns/:id/start — validate + reset counters + flip to
 * "active", then run a bounded send batch on ctx.waitUntil.
 */
app.post("/campaigns/:id/start", async (c) => {
  const userId = c.get("userId");
  const id = c.req.param("id");
  const campaign = await c.env.DB.prepare("SELECT * FROM whatsapp_campaigns WHERE id = ?").bind(id).first();
  if (!campaign || (campaign as any).user_id !== userId) return c.json({ error: "WhatsApp campaign not found" }, 404);
  const camp = mapRow(campaign as Record<string, unknown>, CAMPAIGN_SPEC) as Record<string, any>;

  if (!camp.audience_id) return c.json({ error: "Campaign must have an audience assigned" }, 400);
  const audience = await c.env.DB.prepare("SELECT user_id FROM whatsapp_audiences WHERE id = ?")
    .bind(camp.audience_id)
    .first();
  if (!audience || (audience as any).user_id !== userId) return c.json({ error: "Audience not found" }, 400);

  // Snapshot the audience's whatsapp_contacts (owner-scoped).
  const { results: linkRows } = await c.env.DB.prepare(
    "SELECT contact_id, user_id FROM whatsapp_audience_contacts WHERE audience_id = ?",
  )
    .bind(camp.audience_id)
    .all();
  const contacts: Array<{ contact_id: string; name: string; phone_number: string; email?: string }> = [];
  for (const link of linkRows as Array<Record<string, any>>) {
    if (link.user_id !== userId) continue;
    const contact = await c.env.DB.prepare("SELECT * FROM whatsapp_contacts WHERE id = ?").bind(link.contact_id).first();
    if (!contact || (contact as any).user_id !== userId) continue;
    const ct = contact as Record<string, any>;
    contacts.push({ contact_id: ct.id, name: ct.name, phone_number: ct.phone_number, email: ct.email ?? undefined });
  }
  if (contacts.length === 0) return c.json({ error: "No contacts found in audience" }, 400);

  if (camp.template_id) {
    const template = await c.env.DB.prepare("SELECT user_id FROM whatsapp_templates WHERE id = ?")
      .bind(camp.template_id)
      .first();
    if (!template || (template as any).user_id !== userId) return c.json({ error: "Template not found" }, 400);
  }

  const now = Date.now();
  const { sql, binds } = buildUpdate("whatsapp_campaigns", {
    status: "active",
    started_at: now,
    completed_at: null,
    total_contacts: contacts.length,
    sent_count: 0,
    failed_count: 0,
    outcomes: [],
    updated_at: now,
  });
  await c.env.DB.prepare(sql).bind(...binds, id).run();

  c.executionCtx.waitUntil(runWhatsappBatch(c.env.DB, userId, id));

  return c.json({
    success: true,
    campaign_id: id,
    status: "processing",
    total_contacts: contacts.length,
    scheduled: true,
    batch_size: BATCH_MAX_CONTACTS,
  });
});

/**
 * POST /whatsapp/campaigns/:id/resume — continue a run that yielded with
 * recipients still pending. Idempotent: contacts already present in the
 * campaign's outcomes are skipped.
 */
app.post("/campaigns/:id/resume", async (c) => {
  const userId = c.get("userId");
  const id = c.req.param("id");
  const plan = await prepareWhatsappResume(c.env.DB, userId, id);
  if (!plan.run) {
    const notFound = plan.error === "WhatsApp campaign not found";
    return c.json({ error: plan.error ?? "Campaign is not resumable" }, notFound ? 404 : 400);
  }

  c.executionCtx.waitUntil(plan.run());
  return c.json({ success: true, remaining_before_batch: plan.remaining ?? 0, batch_size: BATCH_MAX_CONTACTS });
});

/**
 * Resume plan for a WhatsApp campaign — shared by the HTTP /resume route above
 * and the cron sweeper (../campaign-cron). See ResumePlan for why the batch is
 * returned unstarted.
 *
 * Ownership is enforced by the userId argument, so the cron — which reads the
 * owning user straight off the row — is as owner-scoped as a request is.
 */
export async function prepareWhatsappResume(
  db: D1Database,
  userId: string,
  campaignId: string,
): Promise<ResumePlan> {
  const row = await db.prepare("SELECT * FROM whatsapp_campaigns WHERE id = ?").bind(campaignId).first();
  if (!row || (row as any).user_id !== userId) return { error: "WhatsApp campaign not found" };
  const camp = mapRow(row as Record<string, unknown>, CAMPAIGN_SPEC) as Record<string, any>;
  if (camp.status !== "active") return { error: `Campaign is '${camp.status}', not active` };

  const remaining = Number(camp.total_contacts || 0) - (Array.isArray(camp.outcomes) ? camp.outcomes.length : 0);
  return { remaining, run: () => runWhatsappBatch(db, userId, campaignId) };
}

/** The audience's contacts, owner-scoped. Re-derived per batch (see runWhatsappBatch). */
async function loadAudienceContacts(
  db: D1Database,
  userId: string,
  audienceId: string,
): Promise<Array<Record<string, any>>> {
  const { results: linkRows } = await db
    .prepare("SELECT contact_id, user_id FROM whatsapp_audience_contacts WHERE audience_id = ?")
    .bind(audienceId)
    .all();
  const contacts: Array<Record<string, any>> = [];
  for (const link of linkRows as Array<Record<string, any>>) {
    if (link.user_id !== userId) continue;
    const contact = await db.prepare("SELECT * FROM whatsapp_contacts WHERE id = ?").bind(link.contact_id).first();
    if (!contact || (contact as any).user_id !== userId) continue;
    contacts.push(contact as Record<string, any>);
  }
  return contacts;
}

/**
 * Bounded WhatsApp send batch.
 *
 * The contact list is re-derived from the audience on every batch rather than
 * snapshotted: whatsapp_campaigns has no column to hold a snapshot, and the
 * outcome set (keyed by contact_id) is what actually guarantees no double-send.
 * A consequence worth knowing: editing the audience mid-run picks up additions
 * and drops removals.
 *
 * Safety: the legacy WhatsApp runners honoured NOTHING — no DNC, no cap, a
 * hardcoded 100ms sleep. Here do_not_call is honoured (it is a phone list and
 * these are phone messages; ignoring it was a bug, not a feature) and
 * min_seconds_between_sends acts as a floor over the 100ms default.
 */
export async function runWhatsappBatch(db: D1Database, userId: string, campaignId: string): Promise<void> {
  const row = await db.prepare("SELECT * FROM whatsapp_campaigns WHERE id = ?").bind(campaignId).first();
  if (!row || (row as any).user_id !== userId) return;
  const camp = mapRow(row as Record<string, unknown>, CAMPAIGN_SPEC) as Record<string, any>;
  if (camp.status !== "active") return;

  const outcomes: Array<Record<string, any>> = Array.isArray(camp.outcomes) ? [...camp.outcomes] : [];
  const done = new Set(outcomes.map((o) => String(o?.contact_id ?? "")).filter(Boolean));

  const cfg = (await db
    .prepare(
      "SELECT meta_access_token, meta_phone_number_id, meta_business_account_id, meta_app_id FROM whatsapp_api_configs WHERE user_id = ?",
    )
    .bind(userId)
    .first()) as Record<string, any> | null;
  const config: WA.MetaConfig = {
    meta_access_token: cfg?.meta_access_token ?? null,
    meta_phone_number_id: cfg?.meta_phone_number_id ?? null,
    meta_business_account_id: cfg?.meta_business_account_id ?? null,
    meta_app_id: cfg?.meta_app_id ?? null,
  };

  let sent = Number(camp.sent_count || 0);
  let failed = Number(camp.failed_count || 0);

  const persist = async (extra: Record<string, unknown> = {}) => {
    const { sql, binds } = buildUpdate("whatsapp_campaigns", {
      outcomes, sent_count: sent, failed_count: failed, updated_at: Date.now(), ...extra,
    });
    await db.prepare(sql).bind(...binds, campaignId).run();
  };

  if (!config.meta_access_token || !config.meta_phone_number_id) {
    await persist({ status: "failed", completed_at: Date.now(), failed: failed });
    return;
  }

  const contacts = camp.audience_id ? await loadAudienceContacts(db, userId, camp.audience_id) : [];
  const safety = await loadSafetySettings(db, userId);
  const dnc = await loadDncSet(db, userId, safety.respectDnc, (value) => WA.normalizePhoneNumber(String(value ?? "")));
  const delayMs = Math.max(WHATSAPP_SEND_DELAY_MS, safety.minDelayMs);

  const templateName = String(camp.template_name ?? "").trim();
  const languageCode = String(camp.template_language ?? "") || "en_US";
  let structure: Record<string, unknown> | null =
    camp.template_structure && typeof camp.template_structure === "object"
      ? (camp.template_structure as Record<string, unknown>)
      : null;
  if (templateName && !structure) {
    structure = (await WA.fetchCanonicalTemplateFromMeta(config, templateName, languageCode).catch(() => null)) as
      | Record<string, unknown>
      | null;
  }
  // One media cache for the whole batch — the edge function shared it across
  // the run, the Convex port lost it by sending one contact per invocation.
  const mediaCache = new Map<string, string>();
  const budget = createBudget();

  for (const contact of contacts) {
    if (done.has(String(contact.id))) continue;
    if (budget.exhausted()) break;
    if ((await readStatus(db, "whatsapp_campaigns", campaignId)) !== "active") return;

    const phoneNumber = WA.normalizePhoneNumber(String(contact.phone_number ?? ""));
    const templateContact = {
      first_name: contact.name,
      name: contact.name,
      phone_number: phoneNumber,
      email: contact.email ?? "",
    };

    if (!phoneNumber) {
      failed += 1;
      outcomes.push({ contact_id: contact.id, phone_number: null, status: "failed", error: "Missing phone number" });
      await persist();
      continue;
    }
    if (safety.respectDnc && dnc.has(phoneNumber)) {
      outcomes.push({ contact_id: contact.id, phone_number: phoneNumber, status: "skipped", error: "On do-not-call list" });
      await persist();
      continue;
    }

    const renderedBody = WA.renderTemplate(String(structure?.bodyText ?? camp.description ?? ""), templateContact);

    try {
      const result = templateName
        ? await WA.sendMetaTemplateMessage(
            config,
            await WA.buildMessagePayload({
              config,
              templateName,
              languageCode,
              templateStructure: structure,
              contact: templateContact,
              mediaCache,
            }),
          )
        : await WA.sendMetaTextMessage(config, phoneNumber, renderedBody);

      sent += 1;
      outcomes.push({
        contact_id: contact.id,
        phone_number: phoneNumber,
        status: "sent",
        provider_message_id: result.providerMessageId,
      });

      // Mirror the send into Chats so the thread shows what went out.
      const conversationId = await upsertConversationRow(db as any, userId, {
        phone_number: phoneNumber,
        contact_name: String(contact.name ?? phoneNumber),
        last_message_text: renderedBody || templateName,
        last_message_at: Date.now(),
      });
      const now = Date.now();
      const { sql, binds } = buildInsert("whatsapp_messages", {
        id: newId(),
        _creation_time: now,
        conversation_id: conversationId,
        user_id: userId,
        direction: "outbound",
        body: renderedBody || templateName,
        provider_message_id: result.providerMessageId,
        status: "sent",
        error_message: null,
        raw_payload: result.rawPayload ?? {},
        sent_at: now,
        created_at: now,
      });
      await db.prepare(sql).bind(...binds).run();
    } catch (error) {
      failed += 1;
      outcomes.push({
        contact_id: contact.id,
        phone_number: phoneNumber,
        status: "failed",
        error: error instanceof Error ? error.message : String(error),
      });
    }

    await persist();
    budget.tick();
    await sleep(delayMs);
  }

  if (outcomes.length >= contacts.length) {
    const now = Date.now();
    await persist({
      // whatsapp_campaigns.status is CHECK-constrained to draft/active/
      // completed/failed, so the message channels' terminal rule doesn't apply:
      // this keeps the legacy "any send at all counts as completed".
      status: sent > 0 ? "completed" : "failed",
      completed_at: now,
      total_contacts: contacts.length,
      // `delivered` stays 0 deliberately — deliveries arrive via webhook receipts.
      delivered: 0,
      failed: failed,
      sent_date: now,
    });
  }
}

// ===========================================================================
// templates_fallback  (convex/whatsapp/fallback.ts) — EMAIL-scoped
// ===========================================================================

const FALLBACK_UPDATABLE = [
  "template_type",
  "content",
  "category",
  "language",
  "status",
  "meta_template_id",
  "body_text",
  "carousel_data",
];

/** The signed-in user's email (templates_fallback is matched on email, not uid). */
async function requireEmail(c: any, userId: string): Promise<string | null> {
  const user = await c.env.DB.prepare("SELECT email FROM users WHERE id = ?").bind(userId).first();
  const email = String((user as any)?.email ?? "").trim();
  return email || null;
}

/** GET /whatsapp/fallback-templates — the user's fallback templates, newest first. */
app.get("/fallback-templates", async (c) => {
  const userId = c.get("userId");
  const email = await requireEmail(c, userId);
  if (!email) return c.json({ error: "User email unavailable" }, 400);
  const { results } = await c.env.DB.prepare("SELECT * FROM templates_fallback WHERE user_email = ?")
    .bind(email)
    .all();
  const rows = mapRows<Record<string, any>>(results as Record<string, unknown>[], FALLBACK_SPEC);
  rows.sort((a, b) => createdAtOf(b) - createdAtOf(a));
  return c.json(rows);
});

/** POST /whatsapp/fallback-templates — create (defaults applied; unique name). */
app.post("/fallback-templates", async (c) => {
  const userId = c.get("userId");
  const email = await requireEmail(c, userId);
  if (!email) return c.json({ error: "User email unavailable" }, 400);
  const b = await c.req.json<Record<string, any>>();
  const templateName = String(b.template_name ?? "").trim();
  if (!templateName) return c.json({ error: "template_name is required" }, 400);

  const existing = await c.env.DB.prepare(
    "SELECT id FROM templates_fallback WHERE user_email = ? AND template_name = ?",
  )
    .bind(email, templateName)
    .first();
  if (existing) return c.json({ error: "A template with this name already exists" }, 409);

  const now = Date.now();
  const id = newId();
  const doc = {
    id,
    _creation_time: now,
    user_email: email,
    template_name: templateName,
    template_type: b.template_type ?? "text",
    content: b.content ?? null,
    category: b.category ?? "UTILITY",
    language: b.language ?? "en_US",
    status: b.status ?? "pending",
    meta_template_id: b.meta_template_id ?? null,
    body_text: b.body_text ?? null,
    carousel_data: b.carousel_data ?? null,
    created_at: now,
    updated_at: now,
  };
  const { sql, binds } = buildInsert("templates_fallback", doc);
  await c.env.DB.prepare(sql).bind(...binds).run();
  const created = await c.env.DB.prepare("SELECT * FROM templates_fallback WHERE id = ?").bind(id).first();
  return c.json(mapRow(created as Record<string, unknown>, FALLBACK_SPEC), 201);
});

/** PATCH /whatsapp/fallback-templates/:id — email-scoped; null clears a column. */
app.patch("/fallback-templates/:id", async (c) => {
  const userId = c.get("userId");
  const email = await requireEmail(c, userId);
  if (!email) return c.json({ error: "User email unavailable" }, 400);
  const id = c.req.param("id");
  const existing = await c.env.DB.prepare("SELECT * FROM templates_fallback WHERE id = ?").bind(id).first();
  if (!existing || (existing as any).user_email !== email) return c.json({ error: "Template not found" }, 404);
  const ex = existing as Record<string, any>;
  const b = await c.req.json<Record<string, any>>();

  if (b.template_name !== undefined && String(b.template_name).trim() !== ex.template_name) {
    const conflict = await c.env.DB.prepare(
      "SELECT id FROM templates_fallback WHERE user_email = ? AND template_name = ?",
    )
      .bind(email, String(b.template_name).trim())
      .first();
    if (conflict && (conflict as any).id !== id) {
      return c.json({ error: "A template with this name already exists" }, 409);
    }
  }

  const patch: Record<string, unknown> = { updated_at: Date.now() };
  if (b.template_name !== undefined) patch.template_name = String(b.template_name).trim();
  for (const key of FALLBACK_UPDATABLE) if (key in b) patch[key] = b[key]; // null clears
  const { sql, binds } = buildUpdate("templates_fallback", patch);
  await c.env.DB.prepare(sql).bind(...binds, id).run();
  const updated = await c.env.DB.prepare("SELECT * FROM templates_fallback WHERE id = ?").bind(id).first();
  return c.json(mapRow(updated as Record<string, unknown>, FALLBACK_SPEC));
});

/** DELETE /whatsapp/fallback-templates/:id — detach audience_campaigns (SET NULL). */
app.delete("/fallback-templates/:id", async (c) => {
  const userId = c.get("userId");
  const email = await requireEmail(c, userId);
  if (!email) return c.json({ error: "User email unavailable" }, 400);
  const id = c.req.param("id");
  const existing = await c.env.DB.prepare("SELECT user_email FROM templates_fallback WHERE id = ?").bind(id).first();
  if (!existing || (existing as any).user_email !== email) return c.json({ error: "Template not found" }, 404);
  await c.env.DB.batch([
    c.env.DB.prepare("UPDATE audience_campaigns SET template_id = NULL WHERE template_id = ?").bind(id),
    c.env.DB.prepare("DELETE FROM templates_fallback WHERE id = ?").bind(id),
  ]);
  return c.json({ success: true });
});

// ===========================================================================
// Per-user config singletons + templates.
//
// The tables shipped in the D1 migration but nothing ever served them, so the
// pages that read these sat on their loading state forever (an unmapped/missing
// read is indistinguishable from "still loading" on the client). Each GET
// returns the caller's single row, or null when they have none yet — null is a
// real answer the UI can render defaults from; undefined is not.
// ===========================================================================

const API_CONFIG_SPEC = { json: [] as string[], bool: [] as string[] };
const AUTO_REPLY_SPEC = { json: [] as string[], bool: ["is_enabled"] };
const WEBHOOK_CFG_SPEC = { json: [] as string[], bool: [] as string[] };
const WEEKLY_REPORT_SPEC = { json: ["button_types", "image_names"], bool: [] as string[] };
const TEMPLATE_SPEC = {
  json: ["button_types", "buttons", "parameter_tokens", "carousel_cards"],
  bool: ["header_enabled", "footer_enabled", "buttons_enabled"],
};

/** The caller's single row from `table`, mapped through `spec`, or null. */
async function getOwnConfig(c: any, table: string, spec: { json: string[]; bool: string[] }) {
  const row = (await c.env.DB.prepare(`SELECT * FROM ${table} WHERE user_id = ? LIMIT 1`)
    .bind(c.get("userId"))
    .first()) as Record<string, unknown> | null;
  return c.json(mapRow(row, spec));
}

/** Insert-or-update the caller's single row in `table` from `patch`. */
async function upsertOwnConfig(c: any, table: string, patch: Record<string, unknown>) {
  const userId = c.get("userId");
  const now = Date.now();
  const existing = (await c.env.DB.prepare(`SELECT id FROM ${table} WHERE user_id = ? LIMIT 1`)
    .bind(userId)
    .first()) as { id: string } | null;

  if (existing) {
    const { sql, binds } = buildUpdate(table, { ...patch, updated_at: now });
    await c.env.DB.prepare(sql).bind(...binds, existing.id).run();
    return c.json({ success: true, id: existing.id });
  }
  const id = newId();
  const { sql, binds } = buildInsert(table, {
    id,
    _creation_time: now,
    user_id: userId,
    ...patch,
    created_at: now,
    updated_at: now,
  });
  await c.env.DB.prepare(sql).bind(...binds).run();
  return c.json({ success: true, id });
}

app.get("/configs/api", (c) => getOwnConfig(c, "whatsapp_api_configs", API_CONFIG_SPEC));
app.get("/configs/auto-reply", (c) => getOwnConfig(c, "whatsapp_auto_reply_configs", AUTO_REPLY_SPEC));
app.get("/configs/webhook", (c) => getOwnConfig(c, "whatsapp_webhook_configs", WEBHOOK_CFG_SPEC));
app.get("/configs/weekly-report", (c) => getOwnConfig(c, "whatsapp_weekly_report_settings", WEEKLY_REPORT_SPEC));

app.post("/configs/api", async (c) => {
  const b = await c.req.json<Record<string, any>>();
  return upsertOwnConfig(c, "whatsapp_api_configs", {
    meta_access_token: b.meta_access_token ?? null,
    meta_phone_number_id: b.meta_phone_number_id ?? null,
    meta_business_account_id: b.meta_business_account_id ?? null,
    meta_app_id: b.meta_app_id ?? null,
    display_phone_number: b.display_phone_number ?? null,
    verified_name: b.verified_name ?? null,
  });
});

app.post("/configs/auto-reply", async (c) => {
  const b = await c.req.json<{ is_enabled?: boolean; webhook_url?: string }>();
  return upsertOwnConfig(c, "whatsapp_auto_reply_configs", {
    is_enabled: b.is_enabled ? 1 : 0,
    webhook_url: b.webhook_url ?? null,
  });
});

app.post("/configs/weekly-report", async (c) => {
  const b = await c.req.json<Record<string, any>>();
  return upsertOwnConfig(c, "whatsapp_weekly_report_settings", {
    prompt: b.prompt ?? "",
    tone: b.tone ?? "",
    language: b.language ?? "",
    // Stored as JSON text; toBind() serialises arrays for us.
    button_types: b.button_types ?? [],
    image_names: b.image_names ?? [],
  });
});

/** GET /templates — the caller's message templates, newest first. */
app.get("/templates", async (c) => {
  const { results } = await c.env.DB.prepare(
    "SELECT * FROM whatsapp_templates WHERE user_id = ? ORDER BY COALESCE(created_at, _creation_time) DESC",
  )
    .bind(c.get("userId"))
    .all();
  return c.json(mapRows(results as Record<string, unknown>[], TEMPLATE_SPEC));
});

// ===========================================================================
// Template management — ports of convex/whatsapp/templates.ts actions
// (createTemplate / deleteTemplate / getTemplateDetails / syncTemplates /
// uploadTemplateImage) and configs.validateCredentials. The Meta Graph logic
// lives verbatim in ../whatsapp-helpers (pure, copied from the convex port);
// only the DB seams are re-implemented on D1 here.
//
// The email-keyed `system: "fallback"` branch is NOT ported: no frontend
// call sites pass it (verified), and templates_fallback has its own routes.
// ===========================================================================

/** The caller's Meta credentials row, or null. */
async function getMetaConfig(c: any, userId: string): Promise<Record<string, any> | null> {
  const row = await c.env.DB.prepare(
    "SELECT * FROM whatsapp_api_configs WHERE user_id = ? LIMIT 1",
  ).bind(userId).first();
  return (row as Record<string, any>) ?? null;
}

/** Upsert one template row on the (user_id, normalized_name, language) key. */
async function upsertTemplateRow(
  c: any,
  userId: string,
  row: Record<string, unknown>,
): Promise<void> {
  const now = Date.now();
  const jsonify = (v: unknown) => JSON.stringify(v ?? []);
  const existing = await c.env.DB.prepare(
    "SELECT id FROM whatsapp_templates WHERE user_id = ? AND normalized_name = ? AND language = ?",
  ).bind(userId, row.normalized_name, row.language).first();

  const fields = {
    template_type: row.template_type ?? "standard",
    name: row.name,
    body: row.body ?? "",
    category: row.category ?? "utility",
    header_enabled: row.header_enabled ? 1 : 0,
    header_type: row.header_type ?? null,
    header_text: row.header_text ?? "",
    footer_enabled: row.footer_enabled ? 1 : 0,
    footer_text: row.footer_text ?? "",
    buttons_enabled: row.buttons_enabled ? 1 : 0,
    button_types: jsonify(row.button_types),
    buttons: jsonify(row.buttons),
    parameter_tokens: jsonify(row.parameter_tokens),
    carousel_cards: jsonify(row.carousel_cards),
    meta_template_id: row.meta_template_id ?? null,
    meta_status: row.meta_status ?? "draft",
    updated_at: now,
  };
  if (existing) {
    const { sql, binds } = buildUpdate("whatsapp_templates", fields);
    await c.env.DB.prepare(sql).bind(...binds, (existing as any).id).run();
  } else {
    const { sql, binds } = buildInsert("whatsapp_templates", {
      id: newId(),
      _creation_time: now,
      user_id: userId,
      normalized_name: row.normalized_name,
      language: row.language ?? "en_US",
      created_at: now,
      ...fields,
    });
    await c.env.DB.prepare(sql).bind(...binds).run();
  }
}

/** POST /whatsapp/templates/create — create on Meta, then cache locally. */
app.post("/templates/create", async (c) => {
  const userId = c.get("userId");
  const requestBody = await c.req.json<Record<string, any>>();

  const structure =
    requestBody.structure && typeof requestBody.structure === "object" ? requestBody.structure : null;
  const name = String(structure?.name ?? requestBody.name ?? "").trim();
  const language = String(structure?.language ?? requestBody.language ?? "").trim();
  const category = String(structure?.category ?? requestBody.category ?? "").trim();
  const headerHandle = String(requestBody.headerHandle ?? "").trim();
  const mainBody = String(requestBody.mainBody ?? "").trim();
  const cards: WA.CarouselCardInput[] = Array.isArray(requestBody.cards) ? requestBody.cards : [];
  const components: WA.TemplateComponent[] = Array.isArray(structure?.components)
    ? structure.components
    : Array.isArray(requestBody.components)
      ? requestBody.components
      : cards.length > 0
        ? WA.buildCarouselComponents(mainBody, cards)
        : [];

  if (!name || !language || !category || components.length === 0) {
    return c.json({ success: false, error: "Missing required fields", message: "Please provide name, language, category, and components array" });
  }
  if (cards.length > 0) {
    if (!mainBody) return c.json({ success: false, error: "Missing required fields", message: "Carousel templates require mainBody." });
    if (cards.length > 10) return c.json({ success: false, error: "Too many cards", message: "Carousel templates support a maximum of 10 cards." });
    for (const [index, card] of cards.entries()) {
      const h = String((card as any)?.headerHandle ?? "").trim();
      const b = String((card as any)?.bodyText ?? "").trim();
      const buttons = Array.isArray((card as any)?.buttons) ? (card as any).buttons : [];
      if (!h || !b || buttons.length === 0) return c.json({ success: false, error: "Invalid carousel card", message: `Carousel card ${index + 1} must include an uploaded image handle, bodyText, and at least one button.` });
      if (buttons.length > 2) return c.json({ success: false, error: "Too many buttons", message: `Carousel card ${index + 1} supports a maximum of 2 buttons.` });
      if (buttons.some((btn: unknown) => !WA.isValidCarouselButton(btn as any))) return c.json({ success: false, error: "Invalid carousel button", message: `Carousel card ${index + 1} has an incomplete button. URL and phone buttons require a value, and quick replies must be 25 characters or fewer.` });
    }
  }

  const normalizedName = WA.normalizeTemplateName(name);
  if (!normalizedName) return c.json({ success: false, error: "Invalid name", message: "Template name must contain letters or numbers after normalization." });
  let finalNormalizedName = normalizedName;

  const templateDetails = WA.parseTemplateDetails(components);
  if (templateDetails.parameterTokens.some(WA.isNumericTemplateParameter)) {
    return c.json({ success: false, error: "Invalid parameter format", message: "Use named placeholders like {{order_number}} instead of numeric placeholders like {{1}}." });
  }

  const cfg = await getMetaConfig(c, userId);
  const metaAccessToken = String(cfg?.meta_access_token || "").trim();
  const metaBusinessAccountId = String(cfg?.meta_business_account_id || "").trim();
  if (!metaAccessToken || !metaBusinessAccountId) {
    return c.json({ success: false, error: "Missing credentials", message: "Please configure your WhatsApp API credentials in Profile Settings." });
  }

  const postTemplate = (n: string) =>
    fetch(`${WA.GRAPH_BASE}/${WA.GRAPH_VERSION}/${metaBusinessAccountId}/message_templates`, {
      method: "POST",
      headers: { authorization: `Bearer ${metaAccessToken}`, "content-type": "application/json" },
      body: JSON.stringify(WA.buildMetaRequestBody(n, language, category, components, headerHandle || undefined)),
    });

  let metaResponse = await postTemplate(finalNormalizedName);
  let responseData: any = await metaResponse.json().catch(() => ({}));
  let renamedFrom: string | null = null;
  if (!metaResponse.ok && WA.shouldRetryCarouselNameConflict(responseData, cards)) {
    renamedFrom = finalNormalizedName;
    finalNormalizedName = WA.buildRetryTemplateName(finalNormalizedName);
    metaResponse = await postTemplate(finalNormalizedName);
    responseData = await metaResponse.json().catch(() => ({}));
  }
  if (!metaResponse.ok) {
    const detailedMessage =
      responseData?.error?.error_user_msg || responseData?.error?.error_user_title ||
      responseData?.error?.error_data?.details || responseData?.error?.message || "Failed to create template";
    return c.json({ success: false, error: "Meta API error", message: detailedMessage, details: responseData });
  }

  const persistedCategory = templateDetails.templateType === "carousel" ? "MARKETING" : category.toUpperCase();
  let dbErrorMessage: string | null = null;
  try {
    await upsertTemplateRow(c, userId, {
      template_type: templateDetails.templateType,
      name,
      normalized_name: finalNormalizedName,
      body: templateDetails.bodyText,
      category: persistedCategory.toLowerCase(),
      language,
      footer_text: templateDetails.footerText,
      button_types: templateDetails.buttonTypes,
      meta_template_id: String(responseData?.id ?? "").trim() || null,
      meta_status: WA.mapMetaStatus(responseData?.status),
    });
  } catch (error) {
    dbErrorMessage = WA.formatErrorMessage(error);
  }

  const base = {
    success: true,
    templateId: responseData?.id,
    status: responseData?.status,
    category: responseData?.category,
    normalizedName: finalNormalizedName,
    structure: {
      name: finalNormalizedName,
      previous_category: String(responseData?.category ?? persistedCategory).toUpperCase(),
      parameter_format: "NAMED",
      components,
      language,
      status: String(responseData?.status ?? ""),
      category: String(responseData?.category ?? category).toUpperCase(),
      id: String(responseData?.id ?? ""),
    },
  };
  if (dbErrorMessage) {
    return c.json({ ...base, message: `Template created in Meta but failed to save locally. ${dbErrorMessage}`, warning: "Database save failed" });
  }
  return c.json({
    ...base,
    message: renamedFrom
      ? `Template submitted to Meta as ${finalNormalizedName} because ${renamedFrom} is still reserved by Meta while the old content is being deleted.`
      : "Template fetched and populated!",
  });
});

/** POST /whatsapp/templates/delete — delete on Meta (multi-strategy), then locally. */
app.post("/templates/delete", async (c) => {
  const userId = c.get("userId");
  const args = await c.req.json<Record<string, any>>();
  const templateId = String(args.templateId ?? "").trim();
  const templateName = String(args.templateName ?? "").trim();
  const metaTemplateId = String(args.metaTemplateId ?? "").trim();
  const language = String(args.language ?? "en_US").trim() || "en_US";
  if (!templateId || !templateName) {
    return c.json({ success: false, error: "Missing required fields", message: "Please provide templateId and templateName." });
  }

  const cfg = await getMetaConfig(c, userId);
  const metaAccessToken = String(cfg?.meta_access_token || "").trim();
  const metaBusinessAccountId = String(cfg?.meta_business_account_id || "").trim();

  if (metaAccessToken && metaBusinessAccountId) {
    const targets = WA.getMetaDeleteTargets(metaBusinessAccountId, metaTemplateId, templateName, language);
    const errors: Array<Record<string, unknown>> = [];
    let deletedOnMeta = false;
    let alreadyMissingOnMeta = false;
    for (const target of targets) {
      const res = await fetch(target.url, {
        method: "DELETE",
        headers: { authorization: `Bearer ${metaAccessToken}`, "content-type": "application/json" },
      });
      const data: any = await res.json().catch(() => ({}));
      if (res.ok && data?.success === true) { deletedOnMeta = true; break; }
      if (WA.isMetaTemplateAlreadyMissing(data)) { alreadyMissingOnMeta = true; continue; }
      errors.push({ strategy: target.label, url: target.url, status: res.status, response: data });
    }
    if (!deletedOnMeta && !alreadyMissingOnMeta) {
      const primary: any = errors.find((e: any) => e?.response?.error?.error_user_msg || e?.response?.error?.message);
      return c.json({
        success: false,
        error: "Meta API error",
        message: primary?.response?.error?.error_user_msg || primary?.response?.error?.message || "Failed to delete template from Meta",
        details: errors,
        meta_template_id: metaTemplateId || null,
      });
    }
  }

  // Local cleanup: campaigns referenced the row via ON DELETE SET NULL.
  const row = await c.env.DB.prepare("SELECT id, user_id FROM whatsapp_templates WHERE id = ?").bind(templateId).first();
  if (row && (row as any).user_id === userId) {
    await c.env.DB.batch([
      c.env.DB.prepare("UPDATE whatsapp_campaigns SET template_id = NULL WHERE template_id = ?").bind(templateId),
      c.env.DB.prepare("DELETE FROM whatsapp_templates WHERE id = ?").bind(templateId),
    ]);
  }
  return c.json({ success: true, message: "Template deleted successfully" });
});

/** GET /whatsapp/templates/details?template_name=&language= */
app.get("/templates/details", async (c) => {
  const userId = c.get("userId");
  const templateName = String(c.req.query("template_name") ?? "").trim();
  const preferredLanguage = String(c.req.query("language") ?? "").trim();
  if (!templateName) return c.json({ success: false, error: "template_name is required" });

  const cfg = await getMetaConfig(c, userId);
  const metaAccessToken = String(cfg?.meta_access_token || "").trim();
  const metaBusinessAccountId = String(cfg?.meta_business_account_id || "").trim();
  if (!metaAccessToken || !metaBusinessAccountId) return c.json({ success: false, error: "User credentials not found" });

  const url =
    `${WA.GRAPH_BASE}/${WA.GRAPH_VERSION}/${metaBusinessAccountId}/message_templates` +
    `?name=${encodeURIComponent(templateName)}&fields=id,name,status,category,language,components`;
  const response = await fetch(url, { headers: { authorization: `Bearer ${metaAccessToken}` } });
  if (!response.ok) {
    const error = await response.json().catch(() => ({}));
    return c.json({ success: false, error: `WhatsApp API error: ${JSON.stringify(error)}` });
  }
  const data: any = await response.json().catch(() => ({}));
  const found = Array.isArray(data?.data) ? data.data : [];
  const exact = found.filter((t: Record<string, unknown>) => t.name === templateName);
  const template = preferredLanguage
    ? (exact.find((t: Record<string, unknown>) => t.language === preferredLanguage) ?? exact[0])
    : exact[0];
  if (!template) return c.json({ success: false, error: "Template not found" });
  return c.json({ success: true, template: WA.parseMetaTemplateStructure(template), raw: template });
});

/** POST /whatsapp/templates/sync — Meta → local cache upsert. */
app.post("/templates/sync", async (c) => {
  const userId = c.get("userId");
  const cfg = await getMetaConfig(c, userId);
  const metaAccessToken = String(cfg?.meta_access_token || "").trim();
  const metaBusinessAccountId = String(cfg?.meta_business_account_id || "").trim();
  if (!metaAccessToken || !metaBusinessAccountId) {
    return c.json({ success: false, error: "Missing credentials", message: "Please configure your WhatsApp API credentials in Profile Settings." });
  }
  try {
    const templates = (await WA.fetchAllMetaTemplates(metaBusinessAccountId, metaAccessToken))
      .filter((t) => !WA.isHiddenMetaSampleTemplate(String((t as any)?.name || "")));
    const rows = WA.dedupeByConflictKey(
      templates.map((template: any) => {
        const details = WA.parseTemplateDetails(
          Array.isArray(template?.components) ? (template.components as WA.TemplateComponent[]) : [],
        );
        const normalizedName = WA.normalizeTemplateName(String(template?.name || ""));
        return {
          template_type: details.templateType,
          name: String(template?.name || normalizedName),
          normalized_name: normalizedName,
          body: details.bodyText,
          category: String(template?.category || "utility").toLowerCase(),
          language: String(template?.language || "en_US"),
          header_enabled: details.headerEnabled,
          header_type: details.headerType,
          header_text: details.headerText,
          footer_enabled: details.footerEnabled,
          footer_text: details.footerText,
          buttons_enabled: details.buttonsEnabled,
          button_types: details.buttonTypes,
          buttons: details.buttons,
          parameter_tokens: details.parameterTokens,
          carousel_cards: details.carouselCards,
          meta_template_id: String(template?.id || "").trim() || null,
          meta_status: WA.mapMetaStatus(template?.status),
        };
      }),
      (row) => `${row.normalized_name}::${row.language}`,
    );
    for (const row of rows) await upsertTemplateRow(c, userId, row);
    return c.json({ success: true, count: templates.length });
  } catch (error) {
    return c.json({ success: false, error: WA.formatErrorMessage(error) });
  }
});

/** POST /whatsapp/templates/upload-image — base64 → Meta resumable upload handle. */
app.post("/templates/upload-image", async (c) => {
  const userId = c.get("userId");
  const args = await c.req.json<Record<string, any>>();
  const fileName = String(args.fileName || "").trim() || `template-${Date.now()}.jpg`;
  const mimeType = String(args.mimeType || "").trim() || "image/jpeg";
  const fileBase64 = String(args.fileBase64 || "").trim();
  if (!fileBase64) return c.json({ success: false, error: "fileBase64 is required" });
  if (!mimeType.startsWith("image/")) return c.json({ success: false, error: "Only image uploads are supported" });

  const fileBytes = WA.decodeBase64FilePayload(fileBase64);
  if (!fileBytes.byteLength) return c.json({ success: false, error: "Uploaded file payload is empty" });
  if (fileBytes.byteLength > 5 * 1024 * 1024) return c.json({ success: false, error: "Image size must be 5MB or smaller" });

  const cfg = await getMetaConfig(c, userId);
  const accessToken = String(cfg?.meta_access_token || "").trim();
  const appId = String(cfg?.meta_app_id || "").trim();
  if (!accessToken || !appId) {
    return c.json({ success: false, error: "Please configure your Meta access token and App ID before uploading carousel images." });
  }
  try {
    const handle = await WA.createMetaTemplateHeaderHandle({ accessToken, appId, fileName, mimeType, fileBytes });
    return c.json({ success: true, handle });
  } catch (error) {
    return c.json({ success: false, error: error instanceof Error ? error.message : "Unknown error" });
  }
});

/** POST /whatsapp/configs/validate — Meta credential validation (3-step). */
app.post("/configs/validate", async (c) => {
  const args = await c.req.json<Record<string, any>>();
  const accessToken = String(args.accessToken ?? "").trim();
  const phoneNumberId = String(args.phoneNumberId ?? "").trim();
  const businessAccountId = String(args.businessAccountId ?? "").trim();
  if (!accessToken || !phoneNumberId || !businessAccountId) {
    return c.json({ valid: false, error: "Missing required fields: accessToken, phoneNumberId, or businessAccountId" });
  }
  try {
    const tokenResponse = await fetch(`${WA.GRAPH_BASE}/${WA.GRAPH_VERSION}/me?access_token=${encodeURIComponent(accessToken)}`);
    if (!tokenResponse.ok) {
      const errorData: any = await tokenResponse.json().catch(() => ({}));
      return c.json({ valid: false, error: "Invalid access token", details: errorData?.error?.message || "The access token is invalid or expired." });
    }
    const phonesResponse = await fetch(
      `${WA.GRAPH_BASE}/${WA.GRAPH_VERSION}/${encodeURIComponent(businessAccountId)}/phone_numbers?access_token=${encodeURIComponent(accessToken)}`,
    );
    if (!phonesResponse.ok) {
      const errorData: any = await phonesResponse.json().catch(() => ({}));
      const code = String(errorData?.error?.code ?? "");
      if (code === "190" || code === "10" || code === "200") {
        return c.json({ valid: false, error: "Access token permissions issue", details: 'Token does not have required permissions for this Business Account. Ensure it includes "whatsapp_business_messaging" and "whatsapp_business_management".' });
      }
      return c.json({ valid: false, error: "Invalid Business Account ID", details: errorData?.error?.message || "The Business Account ID does not match the access token or does not exist." });
    }
    const phonesData: any = await phonesResponse.json().catch(() => ({}));
    const phoneMatch = Array.isArray(phonesData?.data)
      ? phonesData.data.some((p: Record<string, unknown>) => String(p?.id ?? "") === phoneNumberId)
      : false;
    if (!phoneMatch) {
      return c.json({ valid: false, error: "Phone Number ID mismatch", details: `The Phone Number ID (${phoneNumberId}) does not belong to Business Account ${businessAccountId}. Please verify your credentials in Meta Business Manager.` });
    }
    const detailsRes = await fetch(
      `${WA.GRAPH_BASE}/${WA.GRAPH_VERSION}/${encodeURIComponent(phoneNumberId)}?fields=verified_name,display_phone_number,quality_rating&access_token=${encodeURIComponent(accessToken)}`,
    );
    const phoneDetails: any = detailsRes.ok ? await detailsRes.json().catch(() => null) : null;
    const verifiedName = typeof phoneDetails?.verified_name === "string" ? phoneDetails.verified_name.trim() : "";
    const displayPhone = typeof phoneDetails?.display_phone_number === "string" ? phoneDetails.display_phone_number.trim() : "";
    return c.json({
      valid: true,
      verified_name: verifiedName || null,
      display_phone_number: displayPhone || null,
      details: verifiedName
        ? `Connected to: ${verifiedName}${displayPhone ? ` (${displayPhone})` : ""}`
        : "All credentials are valid and properly linked.",
    });
  } catch (error) {
    return c.json({ valid: false, error: "Validation failed", details: error instanceof Error ? error.message : "An unexpected error occurred during validation." });
  }
});

export default app;
