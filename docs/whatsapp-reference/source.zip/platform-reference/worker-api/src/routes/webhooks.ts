import { validTwilioSignature, twilioConfig, reconcileTwilioCall } from "../call-completion";
/**
 * webhooks — INBOUND provider callbacks (Telnyx / Twilio / Meta WhatsApp / xPay).
 *
 * Port of the legacy Supabase edge functions:
 *   - handle-telnyx-webhook  -> POST /telnyx           (call-control + status)
 *   - inbound-message        -> POST /telnyx/sms       (Telnyx SMS inbound -> inbox)
 *   - handle-twilio-status   -> POST /twilio/status    (Twilio call status callback)
 *   - whatsapp-webhook       -> GET/POST /whatsapp/:key(Meta verify handshake + inbound)
 *   - xpay-webhook           -> POST /xpay             (xPay payment events)
 *
 * These are PUBLIC: mounted at /api/webhooks WITHOUT requireUser. Providers hit
 * them with no session token, so every handler is defensive — it verifies the
 * provider signature/token (where the source did) BEFORE any DB write, and when
 * a needed secret is absent it degrades gracefully (200/noop, never 500) so the
 * provider does not hammer retries.
 *
 * D1 note: db.ts helpers (buildInsert/buildUpdate/newId) serialize JSON columns
 * and 0/1 booleans; timestamps are stored as epoch-ms INTEGERs (mirroring the
 * rest of the worker), not ISO strings as the Postgres originals used.
 */
import { Hono } from "hono";
import { buildInsert, buildUpdate, newId } from "../db";
import {
  ensureMinuteBalance,
  deductMinutesForCall,
  requirePositiveBalance,
  resolveEffectiveMaxDurationSeconds,
  type BillingEnv,
} from "../billing-helpers";
import { readPlatformPricing } from "../platform-pricing";
import {
  buildOutboundPromptAndTools,
  buildUltravoxCallBody,
  loadAgentRuntimeRows,
} from "./calls";
import { resolveComposioCallActions, type ComposioActionDef } from "../composio-tools";

type Env = {
  Bindings: {
    DB: D1Database;
    // Optional per-deployment secrets. Absent => signature checks degrade
    // gracefully (the handler still 200s) instead of crashing.
    TELNYX_PUBLIC_KEY?: string;
    XPAY_WEBHOOK_SECRET?: string;
    XPAY_EVENT_SIGNER?: string;
    ADMIN_EMAILS?: string;
    ULTRAVOX_API_KEY?: string;
    COMPOSIO_API_KEY?: string;
  } & BillingEnv & Record<string, string | undefined>;
};

const app = new Hono<Env>();

// ===========================================================================
// Shared helpers
// ===========================================================================

const TERMINAL_STATUSES = new Set(["completed", "busy", "no-answer", "canceled", "failed"]);

function normalizePhoneNumber(value: string | null | undefined): string {
  const digits = String(value ?? "").replace(/[^\d]/g, "");
  return digits ? `+${digits}` : "";
}

function escapeXml(value: unknown): string {
  return String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&apos;");
}

function twimlResponse(inner: string): Response {
  return new Response(`<Response>${inner}</Response>`, {
    status: 200,
    headers: { "Content-Type": "text/xml; charset=utf-8" },
  });
}

function twimlSay(message: string): Response {
  return twimlResponse(`<Say>${escapeXml(message)}</Say>`);
}

function base64ToBytes(base64: string): Uint8Array {
  const cleaned = base64.replace(/-/g, "+").replace(/_/g, "/");
  const padded = cleaned.padEnd(cleaned.length + ((4 - (cleaned.length % 4)) % 4), "=");
  const binary = atob(padded);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  return bytes;
}

function timingSafeEqual(a: Uint8Array, b: Uint8Array): boolean {
  if (a.length !== b.length) return false;
  let mismatch = 0;
  for (let i = 0; i < a.length; i++) mismatch |= a[i] ^ b[i];
  return mismatch === 0;
}

/**
 * Verify a Telnyx Ed25519 webhook signature over `${timestamp}|${rawBody}`.
 * Returns { skipped: true } when TELNYX_PUBLIC_KEY is unset so callers can
 * proceed (matches the env-gated integrations' graceful degradation).
 */
async function verifyTelnyxSignature(
  env: Env["Bindings"],
  req: Request,
  rawBody: string,
): Promise<{ valid: boolean; skipped?: boolean; error?: string }> {
  const publicKey = (env.TELNYX_PUBLIC_KEY ?? "").trim();
  if (!publicKey) return { valid: false, skipped: true, error: "TELNYX_PUBLIC_KEY not set" };

  const signature =
    req.headers.get("telnyx-signature-ed25519") || req.headers.get("telnyx-signature") || "";
  const timestamp = req.headers.get("telnyx-timestamp") || "";
  if (!signature || !timestamp) return { valid: false, error: "Missing Telnyx signature headers" };

  try {
    const key = await crypto.subtle.importKey(
      "raw",
      base64ToBytes(publicKey) as BufferSource,
      { name: "Ed25519" },
      false,
      ["verify"],
    );
    const message = new TextEncoder().encode(`${timestamp}|${rawBody}`);
    const ok = await crypto.subtle.verify(
      "Ed25519",
      key,
      base64ToBytes(signature.trim()) as BufferSource,
      message as BufferSource,
    );
    return ok ? { valid: true } : { valid: false, error: "signature mismatch" };
  } catch (error) {
    return { valid: false, error: `verify error: ${String(error)}` };
  }
}

/**
 * fireAgentWebhooks port — dispatch a call lifecycle event to the user-registered
 * webhooks (`webhooks` table) that subscribe to it. Best-effort; failures are
 * swallowed so a bad customer endpoint never fails our provider ack.
 */
async function fireAgentWebhooks(
  db: D1Database,
  agentId: string | null | undefined,
  event: string,
  payload: Record<string, unknown>,
): Promise<void> {
  if (!agentId) return;
  const { results } = await db
    .prepare("SELECT url, secret, events, is_active FROM webhooks WHERE agent_id = ? AND is_active = 1")
    .bind(agentId)
    .all();
  const hooks = (results as Array<Record<string, any>>).filter((h) => {
    let events: unknown = h.events;
    if (typeof events === "string") {
      try {
        events = JSON.parse(events);
      } catch {
        events = [];
      }
    }
    return Array.isArray(events) && events.includes(event);
  });
  if (!hooks.length) return;
  await Promise.all(
    hooks.map(async (hook) => {
      try {
        const headers: Record<string, string> = { "content-type": "application/json" };
        if (hook.secret) headers["X-Webhook-Secret"] = hook.secret;
        await fetch(hook.url, {
          method: "POST",
          headers,
          body: JSON.stringify({ event, timestamp: new Date().toISOString(), ...payload }),
        });
      } catch {
        /* customer endpoint failures are non-fatal */
      }
    }),
  );
}

// ===========================================================================
// 1) Telnyx call-control webhook  (handle-telnyx-webhook)
//    call.answered -> attach media stream + mark in-progress
//    call.hangup   -> map terminal status, bill the call, clear call state
// ===========================================================================

const TELNYX_TRANSFER_STATE_PREFIX = "transfer-state:";
const TELNYX_INLINE_STREAM_PREFIX = "inline-stream:";
const TELNYX_TRANSFER_LEG_TYPE = "transfer-leg";

type TransferState = {
  currentIndex: number;
  forwardingNumbers: Array<{ phone_number: string; label?: string | null }>;
  fromNumber: string;
  currentLegAnswered?: boolean;
};

function decodeTransferState(value: string | null | undefined): TransferState | null {
  if (!value || !value.startsWith(TELNYX_TRANSFER_STATE_PREFIX)) return null;
  try {
    return JSON.parse(atob(value.slice(TELNYX_TRANSFER_STATE_PREFIX.length)));
  } catch {
    return null;
  }
}

function encodeTransferState(payload: TransferState): string {
  return `${TELNYX_TRANSFER_STATE_PREFIX}${btoa(JSON.stringify(payload))}`;
}

function decodeInlineStreamJoinUrl(value: string | null | undefined): string | null {
  if (!value || !value.startsWith(TELNYX_INLINE_STREAM_PREFIX)) return null;
  return value.slice(TELNYX_INLINE_STREAM_PREFIX.length) || null;
}

function decodeTransferLegState(
  value: string | null | undefined,
): { type: string; originalCallControlId: string; currentIndex: number } | null {
  if (!value) return null;
  try {
    const decoded = JSON.parse(atob(value));
    if (decoded?.type === TELNYX_TRANSFER_LEG_TYPE && decoded?.originalCallControlId) return decoded;
  } catch {
    /* ignore */
  }
  return null;
}

const callStateByControlId = (db: D1Database, id: string) =>
  db.prepare("SELECT * FROM telnyx_call_state WHERE call_control_id = ?").bind(id).first<Record<string, any>>();

app.post("/telnyx", async (c) => {
  const rawBody = await c.req.text();

  // Optional signature check (source did none; we verify when the key is set).
  const sig = await verifyTelnyxSignature(c.env, c.req.raw, rawBody);
  if (!sig.valid && !sig.skipped) {
    console.warn(`[telnyx-webhook] rejected: ${sig.error}`);
    return c.json({ error: "Signature verification failed" }, 401);
  }

  try {
    const body = rawBody ? JSON.parse(rawBody) : {};
    const eventType: string | undefined = body?.data?.event_type;
    const payload: Record<string, any> = body?.data?.payload ?? {};
    const callControlId: string | undefined = payload?.call_control_id;
    if (!callControlId) return c.json({ ok: true });

    const db = c.env.DB;
    const env = c.env as unknown as BillingEnv;

    const existingCallLog = await db
      .prepare(
        "SELECT id, agent_id, user_id, status, caller_number, recipient_number, started_at, billing_status FROM call_logs WHERE twilio_call_sid = ?",
      )
      .bind(callControlId)
      .first<Record<string, any>>();

    // -------- call.answered --------
    if (eventType === "call.answered") {
      const legTransferState = decodeTransferLegState(payload?.client_state);
      const callState = await callStateByControlId(db, callControlId);
      const transferState = decodeTransferState(callState?.join_url);
      const inlineStreamJoinUrl = decodeInlineStreamJoinUrl(callState?.join_url);

      if (!callState) {
        if (legTransferState?.originalCallControlId) {
          const originalCallState = await callStateByControlId(db, legTransferState.originalCallControlId);
          const originalTransferState = decodeTransferState(originalCallState?.join_url);
          if (originalTransferState) {
            await db
              .prepare("UPDATE telnyx_call_state SET join_url = ? WHERE call_control_id = ?")
              .bind(
                encodeTransferState({
                  currentIndex: legTransferState.currentIndex,
                  forwardingNumbers: originalTransferState.forwardingNumbers,
                  fromNumber: originalTransferState.fromNumber,
                  currentLegAnswered: true,
                }),
                legTransferState.originalCallControlId,
              )
              .run();
          }
        }
      } else if (transferState) {
        await db
          .prepare("UPDATE telnyx_call_state SET join_url = ? WHERE call_control_id = ?")
          .bind(
            encodeTransferState({ ...transferState, currentLegAnswered: true }),
            callControlId,
          )
          .run();
      } else if (inlineStreamJoinUrl) {
        await db.prepare("DELETE FROM telnyx_call_state WHERE call_control_id = ?").bind(callControlId).run();
      } else if (callState.telnyx_api_key && callState.join_url) {
        // Attach the AI media stream to the answered leg (external Telnyx API).
        try {
          const res = await fetch(
            `https://api.telnyx.com/v2/calls/${callControlId}/actions/streaming_start`,
            {
              method: "POST",
              headers: {
                authorization: `Bearer ${callState.telnyx_api_key}`,
                "content-type": "application/json",
              },
              body: JSON.stringify({
                stream_url: callState.join_url,
                stream_track: "inbound_track",
                stream_bidirectional_mode: "rtp",
                stream_codec: "PCMU",
                stream_bidirectional_codec: "PCMU",
                stream_bidirectional_sampling_rate: 8000,
                stream_bidirectional_target_legs: "self",
              }),
            },
          );
          if (!res.ok) console.error(`[telnyx-webhook] streaming_start failed: ${await res.text()}`);
        } catch (err) {
          console.error(`[telnyx-webhook] streaming_start error: ${String(err)}`);
        }
        await db.prepare("DELETE FROM telnyx_call_state WHERE call_control_id = ?").bind(callControlId).run();
      }

      await db
        .prepare("UPDATE call_logs SET status = 'in-progress' WHERE twilio_call_sid = ?")
        .bind(callControlId)
        .run();

      if (existingCallLog?.agent_id && existingCallLog.status !== "in-progress") {
        await fireAgentWebhooks(db, existingCallLog.agent_id, "call.started", {
          call_sid: callControlId,
          call_log_id: existingCallLog.id,
          agent_id: existingCallLog.agent_id,
          direction: "outbound",
          caller_number: existingCallLog.caller_number,
          recipient_number: existingCallLog.recipient_number,
          provider: "telnyx",
        });
      }
      return c.json({ ok: true });
    }

    // -------- call.hangup --------
    if (eventType === "call.hangup") {
      const hangupCause = String(payload?.hangup_cause || "unknown");
      const hangupSource = String(payload?.hangup_source || "unknown");
      const sipResponseCode = String(payload?.sip_hangup_cause || "");
      const normalizedCause = hangupCause.toLowerCase();

      let callStatus = "completed";
      if (
        normalizedCause.includes("busy") ||
        normalizedCause.includes("rejected") ||
        normalizedCause.includes("user_busy") ||
        sipResponseCode === "486" ||
        sipResponseCode === "600"
      ) {
        callStatus = "busy";
      } else if (
        normalizedCause.includes("no_answer") ||
        normalizedCause.includes("timeout") ||
        normalizedCause.includes("cancel") ||
        normalizedCause.includes("no_user_responding") ||
        sipResponseCode === "408" ||
        sipResponseCode === "480" ||
        sipResponseCode === "487"
      ) {
        callStatus = "no-answer";
      } else if (
        normalizedCause.includes("unallocated") ||
        normalizedCause.includes("no_route") ||
        normalizedCause.includes("invalid") ||
        normalizedCause.includes("destination_out_of_order")
      ) {
        callStatus = "failed";
      }

      const legTransferState = decodeTransferLegState(payload?.client_state);
      const callState = await callStateByControlId(db, callControlId);
      const originalTransferCallControlId = legTransferState?.originalCallControlId || callControlId;

      let originalTransferState = decodeTransferState(callState?.join_url);
      let originalCallState = callState;
      if (legTransferState?.originalCallControlId && legTransferState.originalCallControlId !== callControlId) {
        originalCallState = await callStateByControlId(db, legTransferState.originalCallControlId);
        originalTransferState = decodeTransferState(originalCallState?.join_url);
      }

      const currentTransferIndex = legTransferState?.currentIndex ?? originalTransferState?.currentIndex ?? 0;
      const currentLegAnswered = Boolean(originalTransferState?.currentLegAnswered);
      const shouldRetryTransfer =
        !!originalTransferState &&
        !currentLegAnswered &&
        currentTransferIndex + 1 < originalTransferState.forwardingNumbers.length;

      if (shouldRetryTransfer && originalCallState?.telnyx_api_key) {
        const nextIndex = currentTransferIndex + 1;
        const nextEntry = originalTransferState!.forwardingNumbers[nextIndex];
        try {
          const res = await fetch(
            `https://api.telnyx.com/v2/calls/${originalTransferCallControlId}/actions/transfer`,
            {
              method: "POST",
              headers: {
                authorization: `Bearer ${originalCallState.telnyx_api_key}`,
                "content-type": "application/json",
              },
              body: JSON.stringify({
                to: nextEntry.phone_number,
                from: originalTransferState!.fromNumber,
                timeout_secs: 10,
                park_after_unbridge: "self",
                client_state: btoa(
                  JSON.stringify({
                    type: TELNYX_TRANSFER_LEG_TYPE,
                    originalCallControlId: originalTransferCallControlId,
                    currentIndex: nextIndex,
                  }),
                ),
                command_id: crypto.randomUUID(),
              }),
            },
          );
          if (res.ok) {
            await db
              .prepare("UPDATE telnyx_call_state SET join_url = ? WHERE call_control_id = ?")
              .bind(
                encodeTransferState({
                  currentIndex: nextIndex,
                  forwardingNumbers: originalTransferState!.forwardingNumbers,
                  fromNumber: originalTransferState!.fromNumber,
                  currentLegAnswered: false,
                }),
                originalTransferCallControlId,
              )
              .run();
            return c.json({ ok: true, retried: true });
          }
          console.error(`[telnyx-webhook] Transfer fallback failed: ${await res.text()}`);
        } catch (err) {
          console.error(`[telnyx-webhook] Transfer fallback error: ${String(err)}`);
        }
      }

      // Resolve the call_log across the original + transferred control ids.
      const resolvedCallLog = await db
        .prepare(
          "SELECT id, agent_id, user_id, status, caller_number, recipient_number, started_at FROM call_logs WHERE twilio_call_sid IN (?, ?) ORDER BY started_at DESC LIMIT 1",
        )
        .bind(callControlId, originalTransferCallControlId)
        .first<Record<string, any>>();
      const effectiveCallLog = resolvedCallLog ?? existingCallLog;
      const startedAt = Number(effectiveCallLog?.started_at ?? 0);
      const resolvedDurationSeconds = startedAt
        ? Math.max(0, Math.round((Date.now() - startedAt) / 1000))
        : 0;

      await db
        .prepare(
          "UPDATE call_logs SET status = ?, ended_at = ?, duration = ?, summary = ? WHERE twilio_call_sid IN (?, ?)",
        )
        .bind(
          callStatus,
          Date.now(),
          resolvedDurationSeconds,
          `Hangup cause: ${hangupCause} (source: ${hangupSource})${sipResponseCode ? `, SIP: ${sipResponseCode}` : ""}`,
          callControlId,
          originalTransferCallControlId,
        )
        .run();

      const terminalAlreadySet = effectiveCallLog?.status
        ? TERMINAL_STATUSES.has(effectiveCallLog.status)
        : false;
      if (effectiveCallLog?.agent_id && !terminalAlreadySet) {
        if (effectiveCallLog.user_id) {
          try {
            await deductMinutesForCall(db, env, {
              user_id: effectiveCallLog.user_id,
              call_log_id: effectiveCallLog.id,
              duration_seconds: resolvedDurationSeconds,
              kind: "live_deduction",
            });
          } catch (err) {
            console.error(`[telnyx-webhook] deductMinutesForCall failed: ${String(err)}`);
          }
        }
        await fireAgentWebhooks(db, effectiveCallLog.agent_id, "call.ended", {
          call_sid: callControlId,
          call_log_id: effectiveCallLog.id,
          agent_id: effectiveCallLog.agent_id,
          direction: "outbound",
          caller_number: effectiveCallLog.caller_number,
          recipient_number: effectiveCallLog.recipient_number,
          provider: "telnyx",
          status: callStatus,
          duration_seconds: resolvedDurationSeconds || null,
          hangup_cause: hangupCause,
          hangup_source: hangupSource,
          sip_code: sipResponseCode,
        });
      }

      await db.prepare("DELETE FROM telnyx_call_state WHERE call_control_id = ?").bind(callControlId).run();
    }

    return c.json({ ok: true });
  } catch (error) {
    console.error("[telnyx-webhook] Error:", error);
    // Return 200 so Telnyx does not retry-storm on our parse/logic errors.
    return c.json({ ok: true });
  }
});

// ===========================================================================
// 2) Telnyx SMS inbound  (inbound-message) -> customer_conversations inbox
// ===========================================================================

/** Append an inbound message to a user's customer_conversations thread. */
async function appendCustomerMessage(
  db: D1Database,
  args: {
    userId: string;
    customerId: string | null;
    customerPhone: string;
    customerName: string;
    messageText: string;
    messageId: string;
    eventStatus: string;
    receivedAtMs: number;
    rawPayload: unknown;
  },
): Promise<void> {
  const conversationId = args.customerId || normalizePhoneNumber(args.customerPhone);
  if (!conversationId) return;
  const now = Date.now();
  const existing = await db
    .prepare("SELECT * FROM customer_conversations WHERE user_id = ? AND customer_id = ?")
    .bind(args.userId, conversationId)
    .first<Record<string, any>>();

  const statusValue = (args.eventStatus || "received").toLowerCase();
  const messageEntry = {
    id: crypto.randomUUID(),
    direction: "inbound",
    content: args.messageText || "",
    status: statusValue,
    providerMessageId: args.messageId,
    timestamp: new Date(args.receivedAtMs).toISOString(),
    statusDetails: {
      provider: "telnyx",
      providerMessageId: args.messageId,
      events: [{ value: statusValue, source: "webhook", checkedAt: new Date(args.receivedAtMs).toISOString(), raw: args.rawPayload ?? null }],
    },
    campaignId: "direct-message",
  };

  let existingMessages: unknown[] = [];
  if (existing) {
    try {
      existingMessages = Array.isArray(existing.messages) ? existing.messages : JSON.parse(existing.messages ?? "[]");
    } catch {
      existingMessages = [];
    }
  }
  const nextMessages = [...existingMessages, messageEntry];

  if (existing) {
    const { sql, binds } = buildUpdate("customer_conversations", {
      customer_name: args.customerName || existing.customer_name || "",
      messages: nextMessages,
      last_message: messageEntry.content,
      last_message_at: args.receivedAtMs,
      unread_count: Number(existing.unread_count || 0) + 1,
      status: existing.status || "open",
      updated_at: now,
    });
    await db.prepare(sql).bind(...binds, existing.id).run();
  } else {
    const { sql, binds } = buildInsert("customer_conversations", {
      id: newId(),
      _creation_time: now,
      user_id: args.userId,
      customer_id: conversationId,
      customer_name: args.customerName || "",
      messages: nextMessages,
      last_message: messageEntry.content,
      last_message_at: args.receivedAtMs,
      unread_count: 1,
      status: "open",
      created_at: now,
      updated_at: now,
    });
    await db.prepare(sql).bind(...binds).run();
  }
}

app.post("/telnyx/sms", async (c) => {
  const rawBody = await c.req.text();

  const sig = await verifyTelnyxSignature(c.env, c.req.raw, rawBody);
  // The source hard-required a valid signature (TELNYX_PUBLIC_KEY). We keep that,
  // but when the key is unset we degrade to 200-noop rather than 401-storm.
  if (sig.skipped) {
    console.warn("[inbound-message] TELNYX_PUBLIC_KEY not set — skipping (noop)");
    return c.json({ success: true, skipped: "signature_unverified" });
  }
  if (!sig.valid) {
    return c.json({ error: "Signature verification failed", details: sig.error }, 401);
  }

  let payload: any;
  try {
    payload = rawBody ? JSON.parse(rawBody) : {};
  } catch {
    return c.json({ error: "Invalid JSON" }, 400);
  }

  const db = c.env.DB;
  const record: Record<string, any> = payload?.data?.record || payload?.data?.payload || {};
  const eventType = String(payload?.data?.event_type || "unknown");
  const fromNumber = normalizePhoneNumber(record?.from?.phone_number || "");
  const toNumber = normalizePhoneNumber(record?.to?.[0]?.phone_number || "");
  const messageText = String(record?.text || "");
  const messageId = String(record?.id || payload?.data?.id || crypto.randomUUID());
  const isSpam = record?.is_spam === true;
  const eventStatus = String(record?.status || record?.to?.[0]?.status || eventType);
  const receivedAtMs = Date.now();
  const fromName = String(record?.from?.name || "");

  // Log every event (mirrors webhook_logs insert in the source).
  try {
    const { sql, binds } = buildInsert("webhook_logs", {
      id: newId(),
      _creation_time: receivedAtMs,
      event_type: eventType,
      event_id: payload?.data?.id ?? null,
      occurred_at: receivedAtMs,
      direction: record?.direction ?? null,
      from_number: fromNumber || null,
      to_number: toNumber || null,
      message_text: messageText || null,
      message_id: messageId,
      status: isSpam ? "spam" : eventStatus,
      processed: false,
      user_id: null,
      error_message: null,
      raw_payload: payload ?? {},
      created_at: receivedAtMs,
    });
    await db.prepare(sql).bind(...binds).run();
  } catch (err) {
    console.error("[inbound-message] webhook_logs insert failed:", err);
  }

  if (eventType !== "message.received") {
    return c.json({ success: true, logged: true, processed: false, eventType });
  }
  if (isSpam) return c.json({ success: true, logged: true, processed: false, filtered: true });
  if (!toNumber || !fromNumber) return c.json({ error: "Missing to/from numbers" }, 400);

  try {
    // Route to the user(s) owning the destination number; fall back to all users.
    const { results: phoneRows } = await db
      .prepare("SELECT user_id, phone_number FROM phone_configs WHERE is_active = 1")
      .all();
    const owners = (phoneRows as Array<Record<string, any>>)
      .filter((r) => normalizePhoneNumber(r.phone_number) === toNumber)
      .map((r) => r.user_id as string);

    let targetUserIds: string[] = owners;
    if (targetUserIds.length === 0) {
      const { results: profileRows } = await db
        .prepare("SELECT user_id FROM profiles ORDER BY created_at ASC")
        .all();
      targetUserIds = (profileRows as Array<Record<string, any>>).map((r) => r.user_id as string);
    }
    if (targetUserIds.length === 0) return c.json({ error: "No users in system" }, 404);

    for (const userId of targetUserIds) {
      // Match an existing CRM customer by phone (customers_data JSON array).
      const customersRow = await db
        .prepare("SELECT customers_data FROM customers WHERE user_id = ?")
        .bind(userId)
        .first<Record<string, any>>();
      let matched: any = null;
      if (customersRow) {
        let data: unknown = customersRow.customers_data;
        if (typeof data === "string") {
          try {
            data = JSON.parse(data);
          } catch {
            data = [];
          }
        }
        if (Array.isArray(data)) {
          matched = data.find((cust: any) => {
            const cand = cust?.phone || cust?.phone_number || cust?.phoneNumber || cust?.customerPhone;
            return normalizePhoneNumber(cand) === fromNumber;
          });
        }
      }
      await appendCustomerMessage(db, {
        userId,
        customerId: matched?.id ? String(matched.id) : null,
        customerPhone: fromNumber,
        customerName: matched?.name || fromName || `Incoming ${fromNumber}`,
        messageText,
        messageId,
        eventStatus,
        receivedAtMs,
        rawPayload: payload,
      });
    }

    await db
      .prepare("UPDATE webhook_logs SET processed = 1, user_id = ? WHERE message_id = ? AND event_type = 'message.received'")
      .bind(targetUserIds[0] ?? null, messageId)
      .run();

    return c.json({ success: true, users: targetUserIds.length, messageId, processed: true });
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    console.error("[inbound-message] error:", error);
    try {
      await db
        .prepare("UPDATE webhook_logs SET error_message = ? WHERE message_id = ? AND event_type = 'message.received'")
        .bind(message, messageId)
        .run();
    } catch {
      /* ignore */
    }
    return c.json({ error: "Failed to process inbound message", details: message }, 500);
  }
});

// ===========================================================================
// 3) Twilio inbound Voice webhook
//    application/x-www-form-urlencoded body -> TwiML stream to Ultravox.
// ===========================================================================

app.post("/twilio/inbound", async (c) => {
  const db = c.env.DB;
  const form = await c.req.parseBody().catch(() => ({} as Record<string, string | File>));
  const callSid = String(form.CallSid ?? "");
  const fromNumber = normalizePhoneNumber(String(form.From ?? form.Caller ?? ""));
  const toNumber = normalizePhoneNumber(String(form.To ?? form.Called ?? ""));

  if (!toNumber) {
    console.error("[twilio-inbound] missing destination number", { callSid });
    return twimlSay("This phone number is not configured.");
  }

  try {
    const phoneConfigRow = await db
      .prepare(
        "SELECT * FROM phone_configs WHERE phone_number = ? AND provider = 'twilio' AND channel = 'voice' AND is_active = 1 ORDER BY updated_at DESC, _creation_time DESC LIMIT 1",
      )
      .bind(toNumber)
      .first<Record<string, any>>();

    if (!phoneConfigRow) {
      console.error("[twilio-inbound] no active phone config", { callSid, toNumber });
      return twimlSay("This phone number is not configured.");
    }

    const inboundAgentId = String(phoneConfigRow.inbound_agent_id || "").trim();
    let agentRow: Record<string, any> | null = null;
    if (inboundAgentId) {
      agentRow = await db
        .prepare("SELECT * FROM agents WHERE id = ? AND user_id = ? AND is_active = 1 LIMIT 1")
        .bind(inboundAgentId, phoneConfigRow.user_id)
        .first<Record<string, any>>();
    }
    if (!agentRow) {
      agentRow = await db
        .prepare("SELECT * FROM agents WHERE phone_number_id = ? AND user_id = ? AND is_active = 1 ORDER BY updated_at DESC, _creation_time DESC LIMIT 1")
        .bind(phoneConfigRow.id, phoneConfigRow.user_id)
        .first<Record<string, any>>();
    }

    if (!agentRow) {
      console.error("[twilio-inbound] no active inbound agent", { callSid, toNumber, phoneConfigId: phoneConfigRow.id });
      return twimlSay("No active AI agent is assigned to this phone number.");
    }

    let balance: { available_seconds: number };
    try {
      balance = await requirePositiveBalance(db, c.env, String(phoneConfigRow.user_id));
    } catch (error) {
      console.error("[twilio-inbound] insufficient balance", {
        callSid,
        userId: phoneConfigRow.user_id,
        error: error instanceof Error ? error.message : String(error),
      });
      return twimlSay("This account has no calling minutes available.");
    }

    const ultravoxApiKey = String(c.env.ULTRAVOX_API_KEY || "").trim();
    if (!ultravoxApiKey) {
      console.error("[twilio-inbound] ULTRAVOX_API_KEY is missing");
      return twimlSay("The AI voice service is not configured.");
    }

    const aiProvider = String(agentRow.ai_provider || "ultravox").toLowerCase();
    if (aiProvider !== "ultravox") {
      // Non-Ultravox agents (gemini native / sarvam cascade) run on the edge
      // voice relay: Twilio streams to it with the call context embedded as
      // <Parameter>s (agent_id, call_sid, log_id, caller, recipient).
      const relayWsUrl = String((c.env as Record<string, unknown>).EDGE_RELAY_WS_URL || "").trim();
      if (String(phoneConfigRow.provider || "twilio") !== "twilio") {
        console.error("[twilio-inbound] edge relay needs Twilio", { callSid, agentId: agentRow.id, aiProvider });
        return twimlSay("This AI agent is not available for phone calls.");
      }
      if (!relayWsUrl) {
        console.error("[twilio-inbound] EDGE_RELAY_WS_URL is not configured", { callSid, agentId: agentRow.id });
        return twimlSay("The AI voice service is not configured.");
      }
      const nowRelay = Date.now();
      const relayLogId = newId();
      const relayLog = buildInsert("call_logs", {
        id: relayLogId,
        _creation_time: nowRelay,
        user_id: phoneConfigRow.user_id,
        agent_id: agentRow.id,
        direction: "inbound",
        caller_number: fromNumber || null,
        recipient_number: toNumber,
        twilio_call_sid: callSid || null,
        ultravox_call_id: null,
        status: "initiated",
        duration: null,
        started_at: nowRelay,
        ended_at: null,
        transcript: null,
        summary: null,
        billing_status: "pending",
        created_at: nowRelay,
      });
      await db.prepare(relayLog.sql).bind(...relayLog.binds).run();
      await fireAgentWebhooks(db, String(agentRow.id), "call.started", {
        call_sid: callSid,
        call_log_id: relayLogId,
        agent_id: agentRow.id,
        direction: "inbound",
        caller_number: fromNumber,
        recipient_number: toNumber,
        provider: "twilio",
      });
      const params = [
        ["agent_id", String(agentRow.id)],
        ["provider", "twilio"],
        ["call_sid", callSid],
        ["log_id", relayLogId],
        ["caller", fromNumber],
        ["recipient", toNumber],
      ].map(([name, value]) => `<Parameter name="${escapeXml(name)}" value="${escapeXml(value)}" />`).join("");
      return twimlResponse(
        `<Connect><Stream url="${escapeXml(relayWsUrl)}">${params}</Stream></Connect>`,
      );
    }

    const effectiveMaxDurationSeconds = resolveEffectiveMaxDurationSeconds(agentRow.max_duration, balance.available_seconds);
    const { kbItems, agentTools, appointmentTools, forwardingNumbers } = await loadAgentRuntimeRows(db, String(agentRow.id));
    let composioActions: ComposioActionDef[] = [];
    try {
      composioActions = await resolveComposioCallActions(c.env.COMPOSIO_API_KEY, String(phoneConfigRow.user_id));
    } catch (error) {
      console.error("[twilio-inbound] composio action load failed", error);
    }

    const origin = new URL(c.req.url).origin;
    const { systemPrompt, selectedTools } = buildOutboundPromptAndTools({
      agent: agentRow,
      composioActions,
      composioExecuteUrl: `${origin}/api/public/composio/execute`,
      kbItems,
      agentTools,
      appointmentTools,
      forwardingNumbers,
      ultravoxApiKey,
      checkAvailabilityUrl: `${origin}/api/calendar/check-availability`,
      bookAppointmentUrl: `${origin}/api/calendar/book`,
    });

    const ultravoxBody = await buildUltravoxCallBody(
      ultravoxApiKey,
      agentRow,
      systemPrompt,
      selectedTools,
      { twilio: {} },
      effectiveMaxDurationSeconds,
    );

    const ultravoxResponse = await fetch("https://api.ultravox.ai/api/calls", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "X-API-Key": ultravoxApiKey,
      },
      body: JSON.stringify(ultravoxBody),
    });
    const ultravoxRaw = await ultravoxResponse.text();
    const ultravoxData: any = (() => {
      if (!ultravoxRaw) return {};
      try {
        return JSON.parse(ultravoxRaw);
      } catch {
        return {};
      }
    })();

    if (!ultravoxResponse.ok || !ultravoxData?.joinUrl) {
      console.error("[twilio-inbound] failed to create Ultravox call", {
        callSid,
        status: ultravoxResponse.status,
        response: ultravoxData?.message || ultravoxData?.error || ultravoxRaw,
      });
      return twimlSay("The AI voice service is temporarily unavailable.");
    }

    const now = Date.now();
    const logId = newId();
    const { sql, binds } = buildInsert("call_logs", {
      id: logId,
      _creation_time: now,
      user_id: phoneConfigRow.user_id,
      agent_id: agentRow.id,
      direction: "inbound",
      caller_number: fromNumber || null,
      recipient_number: toNumber,
      twilio_call_sid: callSid || null,
      ultravox_call_id: ultravoxData.callId || null,
      status: "initiated",
      duration: null,
      started_at: now,
      ended_at: null,
      transcript: null,
      summary: null,
      billing_status: "pending",
      created_at: now,
    });
    await db.prepare(sql).bind(...binds).run();

    await fireAgentWebhooks(db, String(agentRow.id), "call.started", {
      call_sid: callSid,
      call_log_id: logId,
      agent_id: agentRow.id,
      direction: "inbound",
      caller_number: fromNumber,
      recipient_number: toNumber,
      provider: "twilio",
    });

    return twimlResponse(`<Connect><Stream url="${escapeXml(ultravoxData.joinUrl)}" /></Connect>`);
  } catch (error) {
    console.error("[twilio-inbound] Error:", error);
    return twimlSay("The AI receptionist is temporarily unavailable.");
  }
});

// ===========================================================================
// 4) Twilio call-status callback  (handle-twilio-status)
//    application/x-www-form-urlencoded body.
// ===========================================================================

app.post("/twilio/status", async (c) => {
  try {
    const form = new URLSearchParams(await c.req.text());
    const callSid = form.get("CallSid") || "";
    if (!/^CA[0-9a-f]{32}$/i.test(callSid)) return c.text("Invalid call", 400);
    const log = await c.env.DB.prepare("SELECT * FROM call_logs WHERE twilio_call_sid = ? LIMIT 1").bind(callSid).first<any>();
    // A callback may race the initial call-log insert. Request retry instead of losing it.
    if (!log) return c.text("Call not ready", 503);
    const pc = await twilioConfig(c.env.DB, log);
    if (!pc?.twilio_auth_token || form.get("AccountSid") !== pc.twilio_account_sid ||
      !await validTwilioSignature(c.req.url, form, c.req.header("x-twilio-signature") || "", pc.twilio_auth_token)) {
      return c.text("Invalid signature", 403);
    }
    const result = await reconcileTwilioCall(c.env, log, pc);
    if (result?.changed) await fireAgentWebhooks(c.env.DB, log.agent_id, "call.ended", {
      call_sid: callSid, call_log_id: log.id, agent_id: log.agent_id, direction: log.direction,
      caller_number: log.caller_number, recipient_number: log.recipient_number, provider: "twilio",
      status: result.status, duration_seconds: result.duration,
    });
    return c.text("OK", 200);
  } catch (error) {
    console.error("[twilio-status] completion pending", error instanceof Error ? error.message : "lookup failed");
    return c.text("Retry completion", 503);
  }
});

// ===========================================================================
// 4) Meta WhatsApp webhook  (whatsapp-webhook)
//    GET  /whatsapp/:key -> hub.challenge verify handshake
//    POST /whatsapp/:key -> inbound messages + delivery statuses
// ===========================================================================

type WebhookConfig = { id: string; user_id: string; verify_token: string };

async function getWhatsappWebhookConfig(db: D1Database, webhookKey: string): Promise<WebhookConfig | null> {
  if (!webhookKey) return null;
  const row = await db
    .prepare("SELECT id, user_id, verify_token FROM whatsapp_webhook_configs WHERE webhook_key = ?")
    .bind(webhookKey)
    .first<WebhookConfig>();
  return row ?? null;
}

/** Upsert a whatsapp_conversations row and bump unread (inbound). Returns id. */
async function upsertWhatsappConversation(
  db: D1Database,
  userId: string,
  phoneNumber: string,
  contactName: string,
  lastMessageText: string,
  sentAtMs: number,
): Promise<string> {
  const now = Date.now();
  const existing = await db
    .prepare("SELECT id, unread_count FROM whatsapp_conversations WHERE user_id = ? AND phone_number = ?")
    .bind(userId, phoneNumber)
    .first<Record<string, any>>();
  if (existing) {
    const { sql, binds } = buildUpdate("whatsapp_conversations", {
      contact_name: contactName,
      last_message_text: lastMessageText,
      last_message_at: sentAtMs,
      unread_count: Number(existing.unread_count || 0) + 1,
      updated_at: now,
    });
    await db.prepare(sql).bind(...binds, existing.id).run();
    return existing.id;
  }
  const id = newId();
  const { sql, binds } = buildInsert("whatsapp_conversations", {
    id,
    _creation_time: now,
    user_id: userId,
    contact_name: contactName || phoneNumber,
    phone_number: phoneNumber,
    last_message_text: lastMessageText,
    last_message_at: sentAtMs,
    unread_count: 1,
    created_at: now,
    updated_at: now,
  });
  await db.prepare(sql).bind(...binds).run();
  return id;
}

async function upsertWhatsappContact(
  db: D1Database,
  userId: string,
  phoneNumber: string,
  name: string,
  rawContact: unknown,
): Promise<void> {
  const now = Date.now();
  const existing = await db
    .prepare("SELECT id FROM whatsapp_contacts WHERE user_id = ? AND phone_number = ?")
    .bind(userId, phoneNumber)
    .first<Record<string, any>>();
  const metadata = { source: "whatsapp_webhook", contact: rawContact };
  if (existing) {
    const { sql, binds } = buildUpdate("whatsapp_contacts", {
      name: name || phoneNumber,
      metadata,
      updated_at: now,
    });
    await db.prepare(sql).bind(...binds, existing.id).run();
    return;
  }
  const { sql, binds } = buildInsert("whatsapp_contacts", {
    id: newId(),
    _creation_time: now,
    user_id: userId,
    name: name || phoneNumber,
    phone_number: phoneNumber,
    email: null,
    metadata,
    created_at: now,
    updated_at: now,
  });
  await db.prepare(sql).bind(...binds).run();
}

async function handleWhatsappInbound(db: D1Database, config: WebhookConfig, payload: any): Promise<void> {
  const entries = Array.isArray(payload?.entry) ? payload.entry : [];
  for (const entry of entries) {
    for (const change of entry?.changes ?? []) {
      const value = change?.value ?? {};
      const contactsByPhone = new Map<string, { name: string; raw: unknown }>();
      for (const contact of value?.contacts ?? []) {
        const phone = normalizePhoneNumber(contact?.wa_id);
        if (!phone) continue;
        contactsByPhone.set(phone, { name: String(contact?.profile?.name || phone), raw: contact });
      }

      // Inbound messages.
      for (const message of value?.messages ?? []) {
        const phone = normalizePhoneNumber(message?.from);
        if (!phone) continue;
        const contact = contactsByPhone.get(phone);
        const body = String(
          message?.text?.body ||
            message?.button?.text ||
            message?.interactive?.button_reply?.title ||
            "",
        ).trim();
        const sentAtMs = message?.timestamp ? Number(message.timestamp) * 1000 : Date.now();
        const contactName = contact?.name || phone;
        const conversationId = await upsertWhatsappConversation(
          db,
          config.user_id,
          phone,
          contactName,
          body,
          sentAtMs,
        );
        await upsertWhatsappContact(db, config.user_id, phone, contactName, contact?.raw ?? message);

        const now = Date.now();
        const { sql, binds } = buildInsert("whatsapp_messages", {
          id: newId(),
          _creation_time: now,
          conversation_id: conversationId,
          user_id: config.user_id,
          direction: "inbound",
          body: body || "[Unsupported WhatsApp message]",
          provider_message_id: String(message?.id || ""),
          status: "delivered",
          error_message: null,
          raw_payload: message ?? {},
          sent_at: sentAtMs,
          created_at: now,
        });
        await db.prepare(sql).bind(...binds).run();
      }

      // Delivery-receipt status updates.
      for (const status of value?.statuses ?? []) {
        const nextStatus = String(status?.status || "").trim();
        const mapped =
          nextStatus === "read"
            ? "read"
            : nextStatus === "delivered"
              ? "delivered"
              : nextStatus === "failed"
                ? "failed"
                : "sent";
        const patch: Record<string, unknown> = { status: mapped, raw_payload: status };
        if (Array.isArray(status?.errors) && status.errors.length > 0) {
          patch.error_message = String(status.errors[0]?.title || status.errors[0]?.message || "Message failed");
        }
        const cols = Object.keys(patch);
        const setSql = cols.map((k) => `"${k}" = ?`).join(", ");
        const binds = cols.map((k) => {
          const v = patch[k];
          return v !== null && typeof v === "object" ? JSON.stringify(v) : v;
        });
        await db
          .prepare(
            `UPDATE whatsapp_messages SET ${setSql} WHERE user_id = ? AND provider_message_id = ?`,
          )
          .bind(...binds, config.user_id, String(status?.id || ""))
          .run();
      }
    }
  }
}

// GET verify handshake — Meta calls this once when you save the webhook URL.
app.get("/whatsapp/:key", async (c) => {
  const config = await getWhatsappWebhookConfig(c.env.DB, c.req.param("key"));
  if (!config) return c.json({ error: "Webhook configuration not found" }, 404);

  const mode = c.req.query("hub.mode");
  const token = c.req.query("hub.verify_token");
  const challenge = c.req.query("hub.challenge") ?? "";
  if (mode === "subscribe" && token === config.verify_token) {
    return c.text(challenge, 200);
  }
  return c.json({ error: "Verification failed" }, 403);
});

// POST inbound events.
app.post("/whatsapp/:key", async (c) => {
  const db = c.env.DB;
  const config = await getWhatsappWebhookConfig(db, c.req.param("key"));
  if (!config) return c.json({ error: "Webhook configuration not found" }, 404);

  let payload: any;
  try {
    payload = await c.req.json();
  } catch {
    return c.json({ error: "Invalid JSON" }, 400);
  }

  try {
    const eventType = String(payload?.entry?.[0]?.changes?.[0]?.field || "messages");
    const now = Date.now();
    const { sql, binds } = buildInsert("whatsapp_webhook_events", {
      id: newId(),
      _creation_time: now,
      user_id: config.user_id,
      webhook_config_id: config.id,
      event_type: eventType,
      payload: payload ?? {},
      created_at: now,
    });
    await db.prepare(sql).bind(...binds).run();

    await handleWhatsappInbound(db, config, payload);
    return c.json({ success: true });
  } catch (error) {
    console.error("[whatsapp-webhook]", error);
    // 200 so Meta does not disable the subscription on transient failures.
    return c.json({ success: false, error: error instanceof Error ? error.message : String(error) }, 200);
  }
});

// ===========================================================================
// 5) xPay payment webhook  (xpay-webhook)
//    Verifies ECDSA (baked public key) or HMAC-SHA512 (env secret), credits
//    fixed plan minutes, records an idempotent xpay_payment_events row.
// ===========================================================================

// Baked xPay webhook ECDSA public key (SPKI/base64) — same constant the source used.
const XPAY_WEBHOOK_PUBLIC_KEY =
  "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEBlXbsIwGSYhdXBOtdrZr3L346JXi3dOg8vP9NCcTOV0ucLVl/GPi2ZVMsdBISQKTGIhzXY/gddRl846C27TfPw==";

const XPAY_PLAN_CONFIG = [
  { name: "starter", minutes: 190, amounts: [19, 1900] },
  { name: "pro", minutes: 500, amounts: [49, 4900] },
  { name: "ultra", minutes: 1500, amounts: [149, 14900] },
] as const;

const XPAY_HANDLED_EVENTS = new Set(["intent.success", "subscription.cycle_charged", "subscription.trialing"]);

function xpayNormalizeEmail(value: unknown): string {
  return String(value || "").trim().toLowerCase();
}

async function xpayVerifyHmac(signature: string, payload: string, secret: string): Promise<boolean> {
  const key = await crypto.subtle.importKey(
    "raw",
    new TextEncoder().encode(secret) as BufferSource,
    { name: "HMAC", hash: "SHA-512" },
    false,
    ["sign"],
  );
  const digest = await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(payload) as BufferSource);
  return timingSafeEqual(base64ToBytes(signature), new Uint8Array(digest));
}

async function xpayVerifyEcdsa(signature: string, payload: string): Promise<boolean> {
  try {
    const key = await crypto.subtle.importKey(
      "spki",
      base64ToBytes(XPAY_WEBHOOK_PUBLIC_KEY) as BufferSource,
      { name: "ECDSA", namedCurve: "P-256" },
      false,
      ["verify"],
    );
    return await crypto.subtle.verify(
      { name: "ECDSA", hash: "SHA-256" },
      key,
      base64ToBytes(signature) as BufferSource,
      new TextEncoder().encode(payload) as BufferSource,
    );
  } catch {
    return false;
  }
}

/**
 * Returns { verified, method }. ECDSA (baked key) is always available; HMAC needs
 * an env secret. If neither a signature nor secret is present, verified=false.
 */
async function xpayVerify(
  env: Env["Bindings"],
  req: Request,
  rawBody: string,
): Promise<{ verified: boolean; method: "ecdsa" | "hmac" | "none" }> {
  const ecdsaSig = req.headers.get("xpay-private-signature");
  if (ecdsaSig) return { verified: await xpayVerifyEcdsa(ecdsaSig, rawBody), method: "ecdsa" };

  const hmacSig = req.headers.get("xpay-signature");
  const secret = (env.XPAY_WEBHOOK_SECRET || env.XPAY_EVENT_SIGNER || "").trim();
  if (hmacSig && secret) return { verified: await xpayVerifyHmac(hmacSig, rawBody, secret), method: "hmac" };

  return { verified: false, method: "none" };
}

function xpayGetAmountCandidates(rawAmount: unknown): number[] {
  const amount = Number(rawAmount);
  if (!Number.isFinite(amount) || amount <= 0) return [];
  return Array.from(new Set([amount, amount / 100].filter((n) => Number.isFinite(n) && n > 0)));
}

type XpayPlan = { name: string; minutes: number; amounts: number[]; legacyAmounts: number[] };

/**
 * Build the plan→minutes map from the admin's live platform pricing (falls back
 * to the hardcoded defaults). This keeps payment fulfilment in lock-step with
 * whatever prices/minutes the admin set on the Platform Payments page.
 *
 * The hardcoded legacy amounts are KEPT as a second-pass fallback: the "Buy
 * Now" xPay checkout links are static, so a payment made through an old link
 * (old price) must still credit minutes after the admin changes a price —
 * otherwise the customer pays and receives nothing. Current admin prices win
 * when both could match.
 */
async function xpayPlanConfig(db: D1Database): Promise<XpayPlan[]> {
  const legacy = (name: string) => {
    const row = XPAY_PLAN_CONFIG.find((p) => p.name === name);
    return row ? [...row.amounts] : [];
  };
  try {
    const p = await readPlatformPricing(db);
    return [
      { name: "starter", minutes: p.starter_minutes, amounts: [p.starter_price, p.starter_price * 100], legacyAmounts: legacy("starter") },
      { name: "pro", minutes: p.pro_minutes, amounts: [p.pro_price, p.pro_price * 100], legacyAmounts: legacy("pro") },
      { name: "ultra", minutes: p.ultra_minutes, amounts: [p.ultra_price, p.ultra_price * 100], legacyAmounts: legacy("ultra") },
    ];
  } catch {
    return XPAY_PLAN_CONFIG.map((p) => ({ name: p.name, minutes: p.minutes, amounts: [...p.amounts], legacyAmounts: [...p.amounts] }));
  }
}

function xpayResolvePlan(rawAmount: unknown, config: XpayPlan[]) {
  const candidates = xpayGetAmountCandidates(rawAmount);
  // Pass 1: current admin prices. Pass 2: legacy hardcoded amounts (old links).
  for (const key of ["amounts", "legacyAmounts"] as const) {
    for (const plan of config) {
      for (const cand of candidates) {
        if (plan[key].some((a) => Math.abs(cand - a) < 0.0001)) return { ...plan, normalizedAmount: cand };
      }
    }
  }
  return null;
}

const xpayExtractEventType = (p: Record<string, any>) =>
  String(p.eventType || p.event_type || p.type || (p.event as any)?.type || "");
const xpayExtractEventId = (p: Record<string, any>, d: Record<string, any>) =>
  String(
    p.eventId || p.event_id || p.id || d.eventId || d.event_id || d.id || d.intentId || d.intent_id || d.subscriptionId || d.subscription_id || "",
  );
const xpayExtractEmail = (p: Record<string, any>, d: Record<string, any>) =>
  xpayNormalizeEmail(
    (d.customerDetails as any)?.email || (d.customer as any)?.email || d.email || (p.customerDetails as any)?.email || p.email,
  );
const xpayExtractAmount = (p: Record<string, any>, d: Record<string, any>) =>
  d.amount ?? d.chargeAmount ?? d.upfrontAmount ?? (d.payment as any)?.amount ?? p.amount ?? p.chargeAmount ?? p.upfrontAmount;

/**
 * creditFixedPurchasedMinutes port (edge _shared/minute-balance.ts): add
 * plan.minutes*60 seconds to the balance and record a direct_purchase txn.
 */
async function creditFixedMinutes(
  db: D1Database,
  args: { userId: string; creditedMinutes: number; purchaseAmount: number; source: string; notes: string },
): Promise<number> {
  const creditedMinutes = Math.floor(Number(args.creditedMinutes));
  const amount = Number(args.purchaseAmount);
  if (!Number.isFinite(creditedMinutes) || creditedMinutes <= 0) throw new Error("Credited minutes must be > 0");
  if (!Number.isFinite(amount) || amount <= 0) throw new Error("Purchase amount must be > 0");

  const creditedSeconds = creditedMinutes * 60;
  const balance = await ensureMinuteBalance(db, args.userId);
  const nextAvailable = Math.max(0, Number(balance.available_seconds || 0)) + creditedSeconds;
  const now = Date.now();

  await db
    .prepare("UPDATE user_minute_balances SET available_seconds = ?, updated_at = ? WHERE user_id = ?")
    .bind(nextAvailable, now, args.userId)
    .run();

  const ratePerMinute = amount / creditedMinutes;
  const { sql, binds } = buildInsert("minute_transactions", {
    id: newId(),
    _creation_time: now,
    user_id: args.userId,
    call_log_id: null,
    kind: "direct_purchase",
    source: args.source,
    seconds_delta: creditedSeconds,
    rate_per_minute: Number.isFinite(ratePerMinute) ? ratePerMinute : null,
    amount,
    notes: args.notes,
    created_at: now,
  });
  await db.prepare(sql).bind(...binds).run();
  return creditedMinutes;
}

app.post("/xpay", async (c) => {
  const rawBody = await c.req.text();

  const { verified, method } = await xpayVerify(c.env, c.req.raw, rawBody);
  if (!verified) {
    // A signed payload that fails verification is a hard 401. An UNSIGNED payload
    // (no signature header at all) with no secret configured degrades to 200-noop
    // so an unconfigured deployment does not 401-storm.
    const hasSignatureHeader = c.req.raw.headers.get("xpay-private-signature") || c.req.raw.headers.get("xpay-signature");
    if (hasSignatureHeader) return c.json({ error: "Invalid webhook signature" }, 401);
    console.warn("[xpay-webhook] no signature/secret — skipping (noop)");
    return c.json({ success: true, skipped: "signature_unverified" });
  }

  try {
    const payload = JSON.parse(rawBody) as Record<string, any>;
    const data = (payload.data as Record<string, any>) ?? payload;
    const eventType = xpayExtractEventType(payload);
    if (!XPAY_HANDLED_EVENTS.has(eventType)) return c.json({ success: true, ignored: true, eventType });

    const eventId = xpayExtractEventId(payload, data);
    if (!eventId) return c.json({ error: "Missing event id" }, 400);

    const customerEmail = xpayExtractEmail(payload, data);
    if (!customerEmail) return c.json({ success: true, ignored: true, reason: "missing_customer_email", eventId });

    const db = c.env.DB;

    const plan = xpayResolvePlan(xpayExtractAmount(payload, data), await xpayPlanConfig(db));
    if (!plan) return c.json({ success: true, ignored: true, reason: "unmapped_amount", eventId });

    // Idempotency: unique index on provider_event_id.
    const existingEvent = await db
      .prepare("SELECT id FROM xpay_payment_events WHERE provider_event_id = ?")
      .bind(eventId)
      .first<Record<string, any>>();
    if (existingEvent) return c.json({ success: true, duplicate: true, eventId });

    const matchedUser = await db
      .prepare("SELECT id FROM users WHERE lower(email) = ?")
      .bind(customerEmail)
      .first<{ id: string }>();

    let minutesCredited = 0;
    if (matchedUser?.id) {
      try {
        minutesCredited = await creditFixedMinutes(db, {
          userId: matchedUser.id,
          creditedMinutes: plan.minutes,
          purchaseAmount: plan.normalizedAmount,
          source: "xpay",
          notes: `xPay ${eventType} (${eventId}) for ${plan.name} plan`,
        });
      } catch (err) {
        console.error(`[xpay-webhook] credit failed: ${String(err)}`);
      }
    }

    const now = Date.now();
    const { sql, binds } = buildInsert("xpay_payment_events", {
      id: newId(),
      _creation_time: now,
      provider_event_id: eventId,
      event_type: eventType,
      intent_id: String(data.intentId || data.intent_id || payload.intentId || payload.intent_id || "") || null,
      subscription_id:
        String(data.subscriptionId || data.subscription_id || payload.subscriptionId || payload.subscription_id || "") || null,
      customer_email: customerEmail,
      amount: plan.normalizedAmount,
      currency: String(data.currency || payload.currency || "") || null,
      plan_name: plan.name,
      user_id: matchedUser?.id ?? null,
      minutes_credited: minutesCredited,
      raw_payload: payload,
      created_at: now,
    });
    await db.prepare(sql).bind(...binds).run();

    return c.json({
      success: true,
      eventId,
      plan: plan.name,
      method,
      matchedUser: matchedUser?.id ?? null,
      minutesCredited,
    });
  } catch (error) {
    console.error("[xpay-webhook] Error:", error);
    return c.json({ error: error instanceof Error ? error.message : "Unable to process xPay webhook" }, 500);
  }
});

export default app;
